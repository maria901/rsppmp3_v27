/*

wtf

*/

namespace mp3dll
{
    partial class sample
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	this.components = new System.ComponentModel.Container();
        	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sample));
        	this.main_timer = new System.Windows.Forms.Timer(this.components);
        	this.filename = new System.Windows.Forms.TextBox();
        	this.of1 = new System.Windows.Forms.OpenFileDialog();
        	this.label2 = new System.Windows.Forms.Label();
        	this.priority = new System.Windows.Forms.ComboBox();
        	this.waveout = new System.Windows.Forms.ComboBox();
        	this.label3 = new System.Windows.Forms.Label();
        	this.loop = new System.Windows.Forms.CheckBox();
        	this.label4 = new System.Windows.Forms.Label();
        	this.label5 = new System.Windows.Forms.Label();
        	this.label6 = new System.Windows.Forms.Label();
        	this.label7 = new System.Windows.Forms.Label();
        	this.label8 = new System.Windows.Forms.Label();
        	this.label9 = new System.Windows.Forms.Label();
        	this.label10 = new System.Windows.Forms.Label();
        	this.label1 = new System.Windows.Forms.Label();
        	this.label12 = new System.Windows.Forms.Label();
        	this.label14 = new System.Windows.Forms.Label();
        	this.label15 = new System.Windows.Forms.Label();
        	this.label16 = new System.Windows.Forms.Label();
        	this.label17 = new System.Windows.Forms.Label();
        	this.label18 = new System.Windows.Forms.Label();
        	this.label19 = new System.Windows.Forms.Label();
        	this.button10 = new System.Windows.Forms.Button();
        	this.filetowav = new System.Windows.Forms.TextBox();
        	this.morcego_error = new System.Windows.Forms.ListBox();
        	this.menu = new System.Windows.Forms.MenuStrip();
        	this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.button1 = new System.Windows.Forms.Button();
        	this.button3 = new System.Windows.Forms.Button();
        	this.button11 = new System.Windows.Forms.Button();
        	this.button12 = new System.Windows.Forms.Button();
        	this.by_BW = new System.Windows.Forms.LinkLabel();
        	this.Hecho_in_Brasil = new System.Windows.Forms.LinkLabel();
        	this.label24 = new System.Windows.Forms.Label();
        	this.button13 = new System.Windows.Forms.Button();
        	this.button14 = new System.Windows.Forms.Button();
        	this.stereo_as_mono = new System.Windows.Forms.CheckBox();
        	this.bits_per_sample = new System.Windows.Forms.Label();
        	this.label11 = new System.Windows.Forms.Label();
        	this.label13 = new System.Windows.Forms.Label();
        	this.track = new System.Windows.Forms.ComboBox();
        	this.button15 = new System.Windows.Forms.Button();
        	this.convert_timer = new System.Windows.Forms.Timer(this.components);
        	this.button16 = new System.Windows.Forms.Button();
        	this.width_t = new System.Windows.Forms.TextBox();
        	this.button17 = new System.Windows.Forms.Button();
        	this.button18 = new System.Windows.Forms.Button();
        	this.button19 = new System.Windows.Forms.Button();
        	this.button20 = new System.Windows.Forms.Button();
        	this.button21 = new System.Windows.Forms.Button();
        	this.button22 = new System.Windows.Forms.Button();
        	this.button23 = new System.Windows.Forms.Button();
        	this.button24 = new System.Windows.Forms.Button();
        	this.label21 = new System.Windows.Forms.Label();
        	this.full_screen_b = new System.Windows.Forms.Button();
        	this.full_screen_b_ = new System.Windows.Forms.Button();
        	this.button25 = new System.Windows.Forms.Button();
        	this.button26 = new System.Windows.Forms.Button();
        	this.info = new System.Windows.Forms.Label();
        	this.fs = new System.Windows.Forms.Timer(this.components);
        	this.esconde_t = new System.Windows.Forms.Timer(this.components);
        	this.disable_video = new System.Windows.Forms.CheckBox();
        	this.no_draw = new System.Windows.Forms.CheckBox();
        	this.default_w = new System.Windows.Forms.Button();
        	this.cancel_imer = new System.Windows.Forms.Timer(this.components);
        	this.pixel_l = new System.Windows.Forms.Label();
        	this.width_plu_plus = new System.Windows.Forms.Button();
        	this.width_minus_minus = new System.Windows.Forms.Button();
        	this.weird_timer = new System.Windows.Forms.Timer(this.components);
        	this.fs_50 = new System.Windows.Forms.Button();
        	this.fs_200 = new System.Windows.Forms.Button();
        	this.fs_by_heigth = new System.Windows.Forms.Button();
        	this.fs_300 = new System.Windows.Forms.Button();
        	this.fs_400 = new System.Windows.Forms.Button();
        	this.button4 = new System.Windows.Forms.Button();
        	this.randon = new System.Windows.Forms.CheckBox();
        	this.file_l = new System.Windows.Forms.Label();
        	this.sync_t = new System.Windows.Forms.TextBox();
        	this.label22 = new System.Windows.Forms.Label();
        	this.button27 = new System.Windows.Forms.Button();
        	this.play_v12 = new System.Windows.Forms.PictureBox();
        	this.pause_v12 = new System.Windows.Forms.PictureBox();
        	this.resume_v12 = new System.Windows.Forms.PictureBox();
        	this.cancel_v12 = new System.Windows.Forms.PictureBox();
        	this.select_v12 = new System.Windows.Forms.PictureBox();
        	this.open_v12 = new System.Windows.Forms.PictureBox();
        	this.background_p = new System.Windows.Forms.PictureBox();
        	this.dummyimage_p = new System.Windows.Forms.PictureBox();
        	this.dummy2_p = new System.Windows.Forms.PictureBox();
        	this.video_f_p = new System.Windows.Forms.PictureBox();
        	this.video_p = new System.Windows.Forms.PictureBox();
        	this.play_v13 = new System.Windows.Forms.PictureBox();
        	this.pause_v13 = new System.Windows.Forms.PictureBox();
        	this.resume_v13 = new System.Windows.Forms.PictureBox();
        	this.cancel_v13 = new System.Windows.Forms.PictureBox();
        	this.playlist = new System.Windows.Forms.ListView();
        	this.File = new System.Windows.Forms.ColumnHeader();
        	this.path = new System.Windows.Forms.ColumnHeader();
        	this.peak = new amanda_progress.progressbar();
        	this.wave_out_volume = new amanda_progress.progressbar();
        	this.internal_volume = new amanda_progress.progressbar();
        	this.progressbar1 = new amanda_progress.progressbar();
        	this.menu.SuspendLayout();
        	((System.ComponentModel.ISupportInitialize)(this.play_v12)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.pause_v12)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.resume_v12)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.cancel_v12)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.select_v12)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.open_v12)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.background_p)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.dummyimage_p)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.dummy2_p)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.video_f_p)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.video_p)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.play_v13)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.pause_v13)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.resume_v13)).BeginInit();
        	((System.ComponentModel.ISupportInitialize)(this.cancel_v13)).BeginInit();
        	this.SuspendLayout();
        	// 
        	// main_timer
        	// 
        	this.main_timer.Interval = 33;
        	this.main_timer.Tick += new System.EventHandler(this.timer1_Tick);
        	// 
        	// filename
        	// 
        	this.filename.Location = new System.Drawing.Point(105, 26);
        	this.filename.Name = "filename";
        	this.filename.Size = new System.Drawing.Size(585, 20);
        	this.filename.TabIndex = 1;
        	this.filename.TextChanged += new System.EventHandler(this.filename_TextChanged);
        	// 
        	// of1
        	// 
        	this.of1.Title = "Morcego diz abre-te S�samo";
        	// 
        	// label2
        	// 
        	this.label2.AutoSize = true;
        	this.label2.Location = new System.Drawing.Point(968, 391);
        	this.label2.Name = "label2";
        	this.label2.Size = new System.Drawing.Size(69, 13);
        	this.label2.TabIndex = 4;
        	this.label2.Text = "Player priority";
        	// 
        	// priority
        	// 
        	this.priority.FormattingEnabled = true;
        	this.priority.Location = new System.Drawing.Point(1047, 388);
        	this.priority.Name = "priority";
        	this.priority.Size = new System.Drawing.Size(126, 21);
        	this.priority.TabIndex = 5;
        	this.priority.SelectedIndexChanged += new System.EventHandler(this.priority_SelectedIndexChanged);
        	// 
        	// waveout
        	// 
        	this.waveout.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.waveout.FormattingEnabled = true;
        	this.waveout.Location = new System.Drawing.Point(1012, 437);
        	this.waveout.Name = "waveout";
        	this.waveout.Size = new System.Drawing.Size(240, 19);
        	this.waveout.TabIndex = 6;
        	this.waveout.Text = "wave out installed in the system";
        	this.waveout.SelectedIndexChanged += new System.EventHandler(this.waveout_SelectedIndexChanged);
        	// 
        	// label3
        	// 
        	this.label3.AutoSize = true;
        	this.label3.Location = new System.Drawing.Point(1009, 424);
        	this.label3.Name = "label3";
        	this.label3.Size = new System.Drawing.Size(94, 13);
        	this.label3.TabIndex = 7;
        	this.label3.Text = "Wave out devices";
        	// 
        	// loop
        	// 
        	this.loop.AutoSize = true;
        	this.loop.Location = new System.Drawing.Point(967, 31);
        	this.loop.Name = "loop";
        	this.loop.Size = new System.Drawing.Size(50, 17);
        	this.loop.TabIndex = 14;
        	this.loop.Text = "Loop";
        	this.loop.UseVisualStyleBackColor = true;
        	this.loop.MouseUp += new System.Windows.Forms.MouseEventHandler(this.loop_MouseUp);
        	// 
        	// label4
        	// 
        	this.label4.AutoSize = true;
        	this.label4.Location = new System.Drawing.Point(963, 99);
        	this.label4.Name = "label4";
        	this.label4.Size = new System.Drawing.Size(37, 13);
        	this.label4.TabIndex = 17;
        	this.label4.Text = "Status";
        	// 
        	// label5
        	// 
        	this.label5.AutoSize = true;
        	this.label5.Location = new System.Drawing.Point(963, 112);
        	this.label5.Name = "label5";
        	this.label5.Size = new System.Drawing.Size(63, 13);
        	this.label5.TabIndex = 18;
        	this.label5.Text = "Sample rate";
        	// 
        	// label6
        	// 
        	this.label6.AutoSize = true;
        	this.label6.Location = new System.Drawing.Point(963, 164);
        	this.label6.Name = "label6";
        	this.label6.Size = new System.Drawing.Size(34, 13);
        	this.label6.TabIndex = 19;
        	this.label6.Text = "Mode";
        	// 
        	// label7
        	// 
        	this.label7.AutoSize = true;
        	this.label7.Location = new System.Drawing.Point(963, 138);
        	this.label7.Name = "label7";
        	this.label7.Size = new System.Drawing.Size(37, 13);
        	this.label7.TabIndex = 20;
        	this.label7.Text = "Bitrate";
        	// 
        	// label8
        	// 
        	this.label8.AutoSize = true;
        	this.label8.Location = new System.Drawing.Point(963, 125);
        	this.label8.Name = "label8";
        	this.label8.Size = new System.Drawing.Size(51, 13);
        	this.label8.TabIndex = 21;
        	this.label8.Text = "Channels";
        	// 
        	// label9
        	// 
        	this.label9.AutoSize = true;
        	this.label9.Location = new System.Drawing.Point(963, 152);
        	this.label9.Name = "label9";
        	this.label9.Size = new System.Drawing.Size(70, 13);
        	this.label9.TabIndex = 22;
        	this.label9.Text = "Normalization";
        	// 
        	// label10
        	// 
        	this.label10.AutoSize = true;
        	this.label10.Location = new System.Drawing.Point(963, 176);
        	this.label10.Name = "label10";
        	this.label10.Size = new System.Drawing.Size(46, 13);
        	this.label10.TabIndex = 23;
        	this.label10.Text = "Finished";
        	// 
        	// label1
        	// 
        	this.label1.AutoSize = true;
        	this.label1.Location = new System.Drawing.Point(964, 269);
        	this.label1.Name = "label1";
        	this.label1.Size = new System.Drawing.Size(44, 13);
        	this.label1.TabIndex = 25;
        	this.label1.Text = "Position";
        	// 
        	// label12
        	// 
        	this.label12.AutoSize = true;
        	this.label12.Location = new System.Drawing.Point(963, 215);
        	this.label12.Name = "label12";
        	this.label12.Size = new System.Drawing.Size(30, 13);
        	this.label12.TabIndex = 26;
        	this.label12.Text = "Time";
        	// 
        	// label14
        	// 
        	this.label14.AutoSize = true;
        	this.label14.Location = new System.Drawing.Point(963, 189);
        	this.label14.Name = "label14";
        	this.label14.Size = new System.Drawing.Size(69, 13);
        	this.label14.TabIndex = 28;
        	this.label14.Text = "Time position";
        	// 
        	// label15
        	// 
        	this.label15.AutoSize = true;
        	this.label15.Location = new System.Drawing.Point(964, 202);
        	this.label15.Name = "label15";
        	this.label15.Size = new System.Drawing.Size(64, 13);
        	this.label15.TabIndex = 29;
        	this.label15.Text = "Milliseconds";
        	// 
        	// label16
        	// 
        	this.label16.AutoSize = true;
        	this.label16.Location = new System.Drawing.Point(963, 85);
        	this.label16.Name = "label16";
        	this.label16.Size = new System.Drawing.Size(59, 13);
        	this.label16.TabIndex = 30;
        	this.label16.Text = "Media type";
        	// 
        	// label17
        	// 
        	this.label17.AutoSize = true;
        	this.label17.Location = new System.Drawing.Point(964, 227);
        	this.label17.Name = "label17";
        	this.label17.Size = new System.Drawing.Size(83, 13);
        	this.label17.TabIndex = 31;
        	this.label17.Text = "Normalize factor";
        	// 
        	// label18
        	// 
        	this.label18.AutoSize = true;
        	this.label18.Location = new System.Drawing.Point(952, 339);
        	this.label18.Name = "label18";
        	this.label18.Size = new System.Drawing.Size(91, 13);
        	this.label18.TabIndex = 32;
        	this.label18.Text = "Wave out volume";
        	// 
        	// label19
        	// 
        	this.label19.AutoSize = true;
        	this.label19.Location = new System.Drawing.Point(982, 363);
        	this.label19.Name = "label19";
        	this.label19.Size = new System.Drawing.Size(59, 13);
        	this.label19.TabIndex = 34;
        	this.label19.Text = "Internal vol";
        	// 
        	// button10
        	// 
        	this.button10.Location = new System.Drawing.Point(20, 513);
        	this.button10.Name = "button10";
        	this.button10.Size = new System.Drawing.Size(155, 25);
        	this.button10.TabIndex = 41;
        	this.button10.Text = "Convert to wav";
        	this.button10.UseVisualStyleBackColor = true;
        	this.button10.Click += new System.EventHandler(this.button10_Click);
        	// 
        	// filetowav
        	// 
        	this.filetowav.Location = new System.Drawing.Point(181, 515);
        	this.filetowav.Name = "filetowav";
        	this.filetowav.Size = new System.Drawing.Size(509, 20);
        	this.filetowav.TabIndex = 42;
        	this.filetowav.Text = "c:\\back\\net_out.wav";
        	// 
        	// morcego_error
        	// 
        	this.morcego_error.FormattingEnabled = true;
        	this.morcego_error.Location = new System.Drawing.Point(21, 605);
        	this.morcego_error.Name = "morcego_error";
        	this.morcego_error.Size = new System.Drawing.Size(669, 30);
        	this.morcego_error.TabIndex = 46;
        	// 
        	// menu
        	// 
        	this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.aboutToolStripMenuItem});
        	this.menu.Location = new System.Drawing.Point(0, 0);
        	this.menu.Name = "menu";
        	this.menu.Size = new System.Drawing.Size(1294, 24);
        	this.menu.TabIndex = 54;
        	this.menu.Text = "menu";
        	// 
        	// aboutToolStripMenuItem
        	// 
        	this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
        	this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
        	this.aboutToolStripMenuItem.Text = "About";
        	this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
        	// 
        	// button1
        	// 
        	this.button1.Location = new System.Drawing.Point(727, 31);
        	this.button1.Name = "button1";
        	this.button1.Size = new System.Drawing.Size(204, 34);
        	this.button1.TabIndex = 55;
        	this.button1.Text = "Equalizer";
        	this.button1.UseVisualStyleBackColor = true;
        	this.button1.Click += new System.EventHandler(this.button1_Click);
        	// 
        	// button3
        	// 
        	this.button3.Location = new System.Drawing.Point(727, 65);
        	this.button3.Name = "button3";
        	this.button3.Size = new System.Drawing.Size(204, 34);
        	this.button3.TabIndex = 56;
        	this.button3.Text = "Normalize";
        	this.button3.UseVisualStyleBackColor = true;
        	this.button3.Click += new System.EventHandler(this.button3_Click);
        	// 
        	// button11
        	// 
        	this.button11.Location = new System.Drawing.Point(727, 99);
        	this.button11.Name = "button11";
        	this.button11.Size = new System.Drawing.Size(204, 34);
        	this.button11.TabIndex = 57;
        	this.button11.Text = "Spectrum";
        	this.button11.UseVisualStyleBackColor = true;
        	this.button11.Click += new System.EventHandler(this.button11_Click);
        	// 
        	// button12
        	// 
        	this.button12.Location = new System.Drawing.Point(727, 133);
        	this.button12.Name = "button12";
        	this.button12.Size = new System.Drawing.Size(204, 34);
        	this.button12.TabIndex = 58;
        	this.button12.Text = "Debug information";
        	this.button12.UseVisualStyleBackColor = true;
        	this.button12.Click += new System.EventHandler(this.button12_Click_1);
        	// 
        	// by_BW
        	// 
        	this.by_BW.AutoSize = true;
        	this.by_BW.Location = new System.Drawing.Point(450, 639);
        	this.by_BW.Name = "by_BW";
        	this.by_BW.Size = new System.Drawing.Size(244, 13);
        	this.by_BW.TabIndex = 59;
        	this.by_BW.TabStop = true;
        	this.by_BW.Text = "BinaryWork Corp. http://nomade.sourceforge.net/";
        	this.by_BW.Click += new System.EventHandler(this.by_RSP_Software_Click);
        	// 
        	// Hecho_in_Brasil
        	// 
        	this.Hecho_in_Brasil.AutoSize = true;
        	this.Hecho_in_Brasil.LinkColor = System.Drawing.Color.Red;
        	this.Hecho_in_Brasil.Location = new System.Drawing.Point(20, 679);
        	this.Hecho_in_Brasil.Name = "Hecho_in_Brasil";
        	this.Hecho_in_Brasil.Size = new System.Drawing.Size(86, 13);
        	this.Hecho_in_Brasil.TabIndex = 60;
        	this.Hecho_in_Brasil.TabStop = true;
        	this.Hecho_in_Brasil.Text = "Modified in Brazil";
        	// 
        	// label24
        	// 
        	this.label24.AutoSize = true;
        	this.label24.Location = new System.Drawing.Point(964, 241);
        	this.label24.Name = "label24";
        	this.label24.Size = new System.Drawing.Size(79, 13);
        	this.label24.TabIndex = 61;
        	this.label24.Text = "Remaining time";
        	// 
        	// button13
        	// 
        	this.button13.Location = new System.Drawing.Point(727, 168);
        	this.button13.Name = "button13";
        	this.button13.Size = new System.Drawing.Size(204, 34);
        	this.button13.TabIndex = 62;
        	this.button13.Text = "Wave effects";
        	this.button13.UseVisualStyleBackColor = true;
        	this.button13.Click += new System.EventHandler(this.button13_Click);
        	// 
        	// button14
        	// 
        	this.button14.Location = new System.Drawing.Point(1177, 359);
        	this.button14.Name = "button14";
        	this.button14.Size = new System.Drawing.Size(77, 20);
        	this.button14.TabIndex = 63;
        	this.button14.Text = "Vol Reset";
        	this.button14.UseVisualStyleBackColor = true;
        	this.button14.Click += new System.EventHandler(this.button14_Click);
        	// 
        	// stereo_as_mono
        	// 
        	this.stereo_as_mono.AutoSize = true;
        	this.stereo_as_mono.Location = new System.Drawing.Point(967, 46);
        	this.stereo_as_mono.Name = "stereo_as_mono";
        	this.stereo_as_mono.Size = new System.Drawing.Size(121, 17);
        	this.stereo_as_mono.TabIndex = 64;
        	this.stereo_as_mono.Text = "Play stereo as mono";
        	this.stereo_as_mono.UseVisualStyleBackColor = true;
        	this.stereo_as_mono.MouseUp += new System.Windows.Forms.MouseEventHandler(this.stereo_as_mono_MouseUp);
        	// 
        	// bits_per_sample
        	// 
        	this.bits_per_sample.AutoSize = true;
        	this.bits_per_sample.Location = new System.Drawing.Point(964, 255);
        	this.bits_per_sample.Name = "bits_per_sample";
        	this.bits_per_sample.Size = new System.Drawing.Size(78, 13);
        	this.bits_per_sample.TabIndex = 66;
        	this.bits_per_sample.Text = "Bits per sample";
        	// 
        	// label11
        	// 
        	this.label11.AutoSize = true;
        	this.label11.Location = new System.Drawing.Point(18, 566);
        	this.label11.Name = "label11";
        	this.label11.Size = new System.Drawing.Size(128, 13);
        	this.label11.TabIndex = 70;
        	this.label11.Text = "Click on the slider to seek";
        	// 
        	// label13
        	// 
        	this.label13.AutoSize = true;
        	this.label13.Location = new System.Drawing.Point(725, 297);
        	this.label13.Name = "label13";
        	this.label13.Size = new System.Drawing.Size(161, 13);
        	this.label13.TabIndex = 72;
        	this.label13.Text = "Play or convert the track number";
        	// 
        	// track
        	// 
        	this.track.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        	this.track.FormattingEnabled = true;
        	this.track.Location = new System.Drawing.Point(891, 294);
        	this.track.Name = "track";
        	this.track.Size = new System.Drawing.Size(40, 21);
        	this.track.TabIndex = 71;
        	// 
        	// button15
        	// 
        	this.button15.Location = new System.Drawing.Point(844, 272);
        	this.button15.Name = "button15";
        	this.button15.Size = new System.Drawing.Size(88, 20);
        	this.button15.TabIndex = 73;
        	this.button15.Text = "Retrieve tracks";
        	this.button15.UseVisualStyleBackColor = true;
        	this.button15.Click += new System.EventHandler(this.button15_Click);
        	// 
        	// convert_timer
        	// 
        	this.convert_timer.Interval = 40;
        	this.convert_timer.Tick += new System.EventHandler(this.convert_timer_Tick);
        	// 
        	// button16
        	// 
        	this.button16.Location = new System.Drawing.Point(727, 203);
        	this.button16.Name = "button16";
        	this.button16.Size = new System.Drawing.Size(204, 34);
        	this.button16.TabIndex = 78;
        	this.button16.Text = "ID3 tags";
        	this.button16.UseVisualStyleBackColor = true;
        	this.button16.Click += new System.EventHandler(this.button16_Click);
        	// 
        	// width_t
        	// 
        	this.width_t.Location = new System.Drawing.Point(828, 240);
        	this.width_t.Name = "width_t";
        	this.width_t.Size = new System.Drawing.Size(0, 20);
        	this.width_t.TabIndex = 79;
        	// 
        	// button17
        	// 
        	this.button17.Location = new System.Drawing.Point(785, 335);
        	this.button17.Name = "button17";
        	this.button17.Size = new System.Drawing.Size(77, 20);
        	this.button17.TabIndex = 83;
        	this.button17.Text = "Auto";
        	this.button17.UseVisualStyleBackColor = true;
        	this.button17.Click += new System.EventHandler(this.button17_Click);
        	// 
        	// button18
        	// 
        	this.button18.Location = new System.Drawing.Point(785, 556);
        	this.button18.Name = "button18";
        	this.button18.Size = new System.Drawing.Size(77, 20);
        	this.button18.TabIndex = 84;
        	this.button18.Text = "1:1";
        	this.button18.UseVisualStyleBackColor = true;
        	this.button18.Click += new System.EventHandler(this.button18_Click);
        	// 
        	// button19
        	// 
        	this.button19.Location = new System.Drawing.Point(785, 504);
        	this.button19.Name = "button19";
        	this.button19.Size = new System.Drawing.Size(77, 20);
        	this.button19.TabIndex = 85;
        	this.button19.Text = "2.39:1";
        	this.button19.UseVisualStyleBackColor = true;
        	this.button19.Click += new System.EventHandler(this.button19_Click);
        	// 
        	// button20
        	// 
        	this.button20.Location = new System.Drawing.Point(785, 479);
        	this.button20.Name = "button20";
        	this.button20.Size = new System.Drawing.Size(77, 20);
        	this.button20.TabIndex = 86;
        	this.button20.Text = "2.35:1";
        	this.button20.UseVisualStyleBackColor = true;
        	this.button20.Click += new System.EventHandler(this.button20_Click);
        	// 
        	// button21
        	// 
        	this.button21.Location = new System.Drawing.Point(785, 455);
        	this.button21.Name = "button21";
        	this.button21.Size = new System.Drawing.Size(77, 20);
        	this.button21.TabIndex = 87;
        	this.button21.Text = "2.21:1";
        	this.button21.UseVisualStyleBackColor = true;
        	this.button21.Click += new System.EventHandler(this.button21_Click);
        	// 
        	// button22
        	// 
        	this.button22.Location = new System.Drawing.Point(785, 431);
        	this.button22.Name = "button22";
        	this.button22.Size = new System.Drawing.Size(77, 20);
        	this.button22.TabIndex = 88;
        	this.button22.Text = "4:3";
        	this.button22.UseVisualStyleBackColor = true;
        	this.button22.Click += new System.EventHandler(this.button22_Click);
        	// 
        	// button23
        	// 
        	this.button23.Location = new System.Drawing.Point(785, 383);
        	this.button23.Name = "button23";
        	this.button23.Size = new System.Drawing.Size(77, 20);
        	this.button23.TabIndex = 89;
        	this.button23.Text = "16:9";
        	this.button23.UseVisualStyleBackColor = true;
        	this.button23.Click += new System.EventHandler(this.button23_Click);
        	// 
        	// button24
        	// 
        	this.button24.Location = new System.Drawing.Point(785, 359);
        	this.button24.Name = "button24";
        	this.button24.Size = new System.Drawing.Size(77, 20);
        	this.button24.TabIndex = 90;
        	this.button24.Text = "5:4";
        	this.button24.UseVisualStyleBackColor = true;
        	this.button24.Click += new System.EventHandler(this.button24_Click);
        	// 
        	// label21
        	// 
        	this.label21.AutoSize = true;
        	this.label21.Location = new System.Drawing.Point(807, 319);
        	this.label21.Name = "label21";
        	this.label21.Size = new System.Drawing.Size(32, 13);
        	this.label21.TabIndex = 91;
        	this.label21.Text = "Ratio";
        	// 
        	// full_screen_b
        	// 
        	this.full_screen_b.Location = new System.Drawing.Point(795, 580);
        	this.full_screen_b.Name = "full_screen_b";
        	this.full_screen_b.Size = new System.Drawing.Size(156, 37);
        	this.full_screen_b.TabIndex = 92;
        	this.full_screen_b.Text = "Auto";
        	this.full_screen_b.UseVisualStyleBackColor = true;
        	// 
        	// full_screen_b_
        	// 
        	this.full_screen_b_.Location = new System.Drawing.Point(747, 591);
        	this.full_screen_b_.Name = "full_screen_b_";
        	this.full_screen_b_.Size = new System.Drawing.Size(156, 20);
        	this.full_screen_b_.TabIndex = 92;
        	this.full_screen_b_.Text = "Fullscreen";
        	this.full_screen_b_.UseVisualStyleBackColor = true;
        	this.full_screen_b_.Click += new System.EventHandler(this.button25_Click);
        	// 
        	// button25
        	// 
        	this.button25.Location = new System.Drawing.Point(785, 530);
        	this.button25.Name = "button25";
        	this.button25.Size = new System.Drawing.Size(77, 20);
        	this.button25.TabIndex = 95;
        	this.button25.Text = "2.50:1";
        	this.button25.UseVisualStyleBackColor = true;
        	this.button25.Click += new System.EventHandler(this.button25_Click_1);
        	// 
        	// button26
        	// 
        	this.button26.Location = new System.Drawing.Point(785, 407);
        	this.button26.Name = "button26";
        	this.button26.Size = new System.Drawing.Size(77, 20);
        	this.button26.TabIndex = 96;
        	this.button26.Text = "16:10";
        	this.button26.UseVisualStyleBackColor = true;
        	this.button26.Click += new System.EventHandler(this.button26_Click);
        	// 
        	// info
        	// 
        	this.info.AutoSize = true;
        	this.info.Location = new System.Drawing.Point(965, 284);
        	this.info.Name = "info";
        	this.info.Size = new System.Drawing.Size(54, 13);
        	this.info.TabIndex = 97;
        	this.info.Text = "Video info";
        	// 
        	// fs
        	// 
        	this.fs.Interval = 4000;
        	this.fs.Tick += new System.EventHandler(this.fs_Tick);
        	// 
        	// esconde_t
        	// 
        	this.esconde_t.Interval = 3000;
        	this.esconde_t.Tick += new System.EventHandler(this.esconde_t_Tick);
        	// 
        	// disable_video
        	// 
        	this.disable_video.AutoSize = true;
        	this.disable_video.Location = new System.Drawing.Point(569, 441);
        	this.disable_video.Name = "disable_video";
        	this.disable_video.Size = new System.Drawing.Size(91, 17);
        	this.disable_video.TabIndex = 102;
        	this.disable_video.Text = "Disable Video";
        	this.disable_video.UseVisualStyleBackColor = true;
        	this.disable_video.MouseUp += new System.Windows.Forms.MouseEventHandler(this.disable_video_MouseUp);
        	// 
        	// no_draw
        	// 
        	this.no_draw.AutoSize = true;
        	this.no_draw.Location = new System.Drawing.Point(569, 464);
        	this.no_draw.Name = "no_draw";
        	this.no_draw.Size = new System.Drawing.Size(106, 17);
        	this.no_draw.TabIndex = 103;
        	this.no_draw.Text = "Don\'t draw video";
        	this.no_draw.UseVisualStyleBackColor = true;
        	this.no_draw.MouseUp += new System.Windows.Forms.MouseEventHandler(this.no_draw_MouseUp);
        	// 
        	// default_w
        	// 
        	this.default_w.Location = new System.Drawing.Point(747, 611);
        	this.default_w.Name = "default_w";
        	this.default_w.Size = new System.Drawing.Size(156, 21);
        	this.default_w.TabIndex = 104;
        	this.default_w.Text = "Fullscreen (default size)";
        	this.default_w.UseVisualStyleBackColor = true;
        	this.default_w.Click += new System.EventHandler(this.default_w_Click);
        	// 
        	// cancel_imer
        	// 
        	this.cancel_imer.Interval = 1000;
        	this.cancel_imer.Tick += new System.EventHandler(this.cancel_imer_Tick);
        	// 
        	// pixel_l
        	// 
        	this.pixel_l.AutoSize = true;
        	this.pixel_l.Location = new System.Drawing.Point(963, 297);
        	this.pixel_l.Name = "pixel_l";
        	this.pixel_l.Size = new System.Drawing.Size(64, 13);
        	this.pixel_l.TabIndex = 106;
        	this.pixel_l.Text = "Pixel Format";
        	// 
        	// width_plu_plus
        	// 
        	this.width_plu_plus.Location = new System.Drawing.Point(950, 541);
        	this.width_plu_plus.Name = "width_plu_plus";
        	this.width_plu_plus.Size = new System.Drawing.Size(77, 42);
        	this.width_plu_plus.TabIndex = 108;
        	this.width_plu_plus.Text = "width++  (F11)";
        	this.width_plu_plus.UseVisualStyleBackColor = true;
        	this.width_plu_plus.Click += new System.EventHandler(this.width_plu_plus_Click);
        	// 
        	// width_minus_minus
        	// 
        	this.width_minus_minus.Location = new System.Drawing.Point(1033, 541);
        	this.width_minus_minus.Name = "width_minus_minus";
        	this.width_minus_minus.Size = new System.Drawing.Size(77, 42);
        	this.width_minus_minus.TabIndex = 109;
        	this.width_minus_minus.Text = "width--   (F12)";
        	this.width_minus_minus.UseVisualStyleBackColor = true;
        	this.width_minus_minus.Click += new System.EventHandler(this.width_minus_minus_Click);
        	// 
        	// weird_timer
        	// 
        	this.weird_timer.Interval = 50;
        	this.weird_timer.Tick += new System.EventHandler(this.weird_timer_Tick);
        	// 
        	// fs_50
        	// 
        	this.fs_50.Location = new System.Drawing.Point(919, 591);
        	this.fs_50.Name = "fs_50";
        	this.fs_50.Size = new System.Drawing.Size(156, 20);
        	this.fs_50.TabIndex = 110;
        	this.fs_50.Text = "Fullscreen 50%";
        	this.fs_50.UseVisualStyleBackColor = true;
        	this.fs_50.Click += new System.EventHandler(this.fs_50_Click);
        	// 
        	// fs_200
        	// 
        	this.fs_200.Location = new System.Drawing.Point(919, 611);
        	this.fs_200.Name = "fs_200";
        	this.fs_200.Size = new System.Drawing.Size(156, 20);
        	this.fs_200.TabIndex = 111;
        	this.fs_200.Text = "Fullscreen 200%";
        	this.fs_200.UseVisualStyleBackColor = true;
        	this.fs_200.Click += new System.EventHandler(this.fs_200_Click);
        	// 
        	// fs_by_heigth
        	// 
        	this.fs_by_heigth.Location = new System.Drawing.Point(747, 632);
        	this.fs_by_heigth.Name = "fs_by_heigth";
        	this.fs_by_heigth.Size = new System.Drawing.Size(156, 20);
        	this.fs_by_heigth.TabIndex = 112;
        	this.fs_by_heigth.Text = "Fullscreen by height";
        	this.fs_by_heigth.UseVisualStyleBackColor = true;
        	this.fs_by_heigth.Click += new System.EventHandler(this.fs_by_heigth_Click);
        	// 
        	// fs_300
        	// 
        	this.fs_300.Location = new System.Drawing.Point(919, 632);
        	this.fs_300.Name = "fs_300";
        	this.fs_300.Size = new System.Drawing.Size(156, 20);
        	this.fs_300.TabIndex = 113;
        	this.fs_300.Text = "Fullscreen 300%";
        	this.fs_300.UseVisualStyleBackColor = true;
        	this.fs_300.Click += new System.EventHandler(this.fs_300_Click);
        	// 
        	// fs_400
        	// 
        	this.fs_400.Location = new System.Drawing.Point(1096, 591);
        	this.fs_400.Name = "fs_400";
        	this.fs_400.Size = new System.Drawing.Size(156, 20);
        	this.fs_400.TabIndex = 114;
        	this.fs_400.Text = "Fullscreen 400%";
        	this.fs_400.UseVisualStyleBackColor = true;
        	this.fs_400.Click += new System.EventHandler(this.fs_400_Click);
        	// 
        	// button4
        	// 
        	this.button4.Location = new System.Drawing.Point(727, 245);
        	this.button4.Name = "button4";
        	this.button4.Size = new System.Drawing.Size(82, 20);
        	this.button4.TabIndex = 116;
        	this.button4.Text = "Playlist";
        	this.button4.UseVisualStyleBackColor = true;
        	this.button4.Click += new System.EventHandler(this.button4_Click_1);
        	// 
        	// randon
        	// 
        	this.randon.AutoSize = true;
        	this.randon.Location = new System.Drawing.Point(728, 270);
        	this.randon.Name = "randon";
        	this.randon.Size = new System.Drawing.Size(59, 17);
        	this.randon.TabIndex = 117;
        	this.randon.Text = "Shuffle";
        	this.randon.UseVisualStyleBackColor = true;
        	this.randon.MouseUp += new System.Windows.Forms.MouseEventHandler(this.randon_MouseUp);
        	// 
        	// file_l
        	// 
        	this.file_l.AutoSize = true;
        	this.file_l.Location = new System.Drawing.Point(20, 438);
        	this.file_l.Name = "file_l";
        	this.file_l.Size = new System.Drawing.Size(161, 13);
        	this.file_l.TabIndex = 118;
        	this.file_l.Text = "Play or convert the track number";
        	// 
        	// sync_t
        	// 
        	this.sync_t.Location = new System.Drawing.Point(955, 486);
        	this.sync_t.Name = "sync_t";
        	this.sync_t.Size = new System.Drawing.Size(103, 20);
        	this.sync_t.TabIndex = 119;
        	this.sync_t.Text = "0";
        	// 
        	// label22
        	// 
        	this.label22.AutoSize = true;
        	this.label22.Location = new System.Drawing.Point(952, 470);
        	this.label22.Name = "label22";
        	this.label22.Size = new System.Drawing.Size(182, 13);
        	this.label22.TabIndex = 120;
        	this.label22.Text = "Audio and video delay in milliseconds";
        	// 
        	// button27
        	// 
        	this.button27.Location = new System.Drawing.Point(1064, 485);
        	this.button27.Name = "button27";
        	this.button27.Size = new System.Drawing.Size(77, 20);
        	this.button27.TabIndex = 121;
        	this.button27.Text = "set";
        	this.button27.UseVisualStyleBackColor = true;
        	this.button27.Click += new System.EventHandler(this.button27_Click);
        	// 
        	// play_v12
        	// 
        	this.play_v12.BackColor = System.Drawing.Color.Transparent;
        	this.play_v12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.play_v12.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.play_v12.Image = global::mp3dll.Properties.Resources.play;
        	this.play_v12.Location = new System.Drawing.Point(105, 48);
        	this.play_v12.Name = "play_v12";
        	this.play_v12.Size = new System.Drawing.Size(80, 42);
        	this.play_v12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.play_v12.TabIndex = 127;
        	this.play_v12.TabStop = false;
        	this.play_v12.Click += new System.EventHandler(this.play_v12_Click);
        	// 
        	// pause_v12
        	// 
        	this.pause_v12.BackColor = System.Drawing.Color.Transparent;
        	this.pause_v12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.pause_v12.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.pause_v12.Image = global::mp3dll.Properties.Resources.pausar;
        	this.pause_v12.Location = new System.Drawing.Point(191, 48);
        	this.pause_v12.Name = "pause_v12";
        	this.pause_v12.Size = new System.Drawing.Size(80, 42);
        	this.pause_v12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.pause_v12.TabIndex = 126;
        	this.pause_v12.TabStop = false;
        	this.pause_v12.Click += new System.EventHandler(this.pause_v12_Click);
        	// 
        	// resume_v12
        	// 
        	this.resume_v12.BackColor = System.Drawing.Color.Transparent;
        	this.resume_v12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.resume_v12.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.resume_v12.Image = global::mp3dll.Properties.Resources.resume;
        	this.resume_v12.Location = new System.Drawing.Point(277, 48);
        	this.resume_v12.Name = "resume_v12";
        	this.resume_v12.Size = new System.Drawing.Size(80, 42);
        	this.resume_v12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.resume_v12.TabIndex = 125;
        	this.resume_v12.TabStop = false;
        	this.resume_v12.Click += new System.EventHandler(this.resume_v12_Click);
        	// 
        	// cancel_v12
        	// 
        	this.cancel_v12.BackColor = System.Drawing.Color.Transparent;
        	this.cancel_v12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.cancel_v12.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.cancel_v12.Image = global::mp3dll.Properties.Resources.cancel;
        	this.cancel_v12.Location = new System.Drawing.Point(363, 48);
        	this.cancel_v12.Name = "cancel_v12";
        	this.cancel_v12.Size = new System.Drawing.Size(80, 42);
        	this.cancel_v12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.cancel_v12.TabIndex = 124;
        	this.cancel_v12.TabStop = false;
        	this.cancel_v12.Click += new System.EventHandler(this.cancel_v12_Click);
        	// 
        	// select_v12
        	// 
        	this.select_v12.BackColor = System.Drawing.Color.Transparent;
        	this.select_v12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.select_v12.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.select_v12.Image = global::mp3dll.Properties.Resources.select;
        	this.select_v12.Location = new System.Drawing.Point(19, 25);
        	this.select_v12.Name = "select_v12";
        	this.select_v12.Size = new System.Drawing.Size(80, 22);
        	this.select_v12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.select_v12.TabIndex = 123;
        	this.select_v12.TabStop = false;
        	this.select_v12.Click += new System.EventHandler(this.select_v12_Click);
        	// 
        	// open_v12
        	// 
        	this.open_v12.BackColor = System.Drawing.Color.Transparent;
        	this.open_v12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.open_v12.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.open_v12.Image = global::mp3dll.Properties.Resources.open;
        	this.open_v12.Location = new System.Drawing.Point(19, 48);
        	this.open_v12.Name = "open_v12";
        	this.open_v12.Size = new System.Drawing.Size(80, 42);
        	this.open_v12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.open_v12.TabIndex = 122;
        	this.open_v12.TabStop = false;
        	this.open_v12.Click += new System.EventHandler(this.open_v12_Click);
        	// 
        	// background_p
        	// 
        	this.background_p.BackColor = System.Drawing.Color.Black;
        	this.background_p.Image = global::mp3dll.Properties.Resources.vazio;
        	this.background_p.Location = new System.Drawing.Point(677, 319);
        	this.background_p.Name = "background_p";
        	this.background_p.Size = new System.Drawing.Size(92, 85);
        	this.background_p.TabIndex = 105;
        	this.background_p.TabStop = false;
        	this.background_p.Visible = false;
        	this.background_p.MouseClick += new System.Windows.Forms.MouseEventHandler(this.background_p_MouseClick);
        	this.background_p.MouseMove += new System.Windows.Forms.MouseEventHandler(this.background_p_MouseMove);
        	// 
        	// dummyimage_p
        	// 
        	this.dummyimage_p.Image = ((System.Drawing.Image)(resources.GetObject("dummyimage_p.Image")));
        	this.dummyimage_p.Location = new System.Drawing.Point(406, 319);
        	this.dummyimage_p.Name = "dummyimage_p";
        	this.dummyimage_p.Size = new System.Drawing.Size(92, 85);
        	this.dummyimage_p.TabIndex = 93;
        	this.dummyimage_p.TabStop = false;
        	this.dummyimage_p.Visible = false;
        	// 
        	// dummy2_p
        	// 
        	this.dummy2_p.Image = global::mp3dll.Properties.Resources.vazio;
        	this.dummy2_p.Location = new System.Drawing.Point(590, 311);
        	this.dummy2_p.Name = "dummy2_p";
        	this.dummy2_p.Size = new System.Drawing.Size(92, 85);
        	this.dummy2_p.TabIndex = 94;
        	this.dummy2_p.TabStop = false;
        	this.dummy2_p.Visible = false;
        	// 
        	// video_f_p
        	// 
        	this.video_f_p.BackColor = System.Drawing.Color.Black;
        	this.video_f_p.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.video_f_p.Location = new System.Drawing.Point(69, 202);
        	this.video_f_p.Name = "video_f_p";
        	this.video_f_p.Size = new System.Drawing.Size(306, 150);
        	this.video_f_p.TabIndex = 82;
        	this.video_f_p.TabStop = false;
        	this.video_f_p.MouseClick += new System.Windows.Forms.MouseEventHandler(this.video_f_p_MouseClick);
        	this.video_f_p.MouseMove += new System.Windows.Forms.MouseEventHandler(this.video_f_p_MouseMove);
        	// 
        	// video_p
        	// 
        	this.video_p.BackColor = System.Drawing.Color.Black;
        	this.video_p.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.video_p.Location = new System.Drawing.Point(20, 92);
        	this.video_p.Name = "video_p";
        	this.video_p.Size = new System.Drawing.Size(670, 338);
        	this.video_p.TabIndex = 81;
        	this.video_p.TabStop = false;
        	this.video_p.MouseClick += new System.Windows.Forms.MouseEventHandler(this.video_p_MouseClick);
        	this.video_p.MouseMove += new System.Windows.Forms.MouseEventHandler(this.video_p_MouseMove);
        	// 
        	// play_v13
        	// 
        	this.play_v13.BackColor = System.Drawing.Color.Transparent;
        	this.play_v13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.play_v13.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.play_v13.Image = global::mp3dll.Properties.Resources.play;
        	this.play_v13.Location = new System.Drawing.Point(24, 520);
        	this.play_v13.Name = "play_v13";
        	this.play_v13.Size = new System.Drawing.Size(80, 42);
        	this.play_v13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.play_v13.TabIndex = 131;
        	this.play_v13.TabStop = false;
        	this.play_v13.Visible = false;
        	this.play_v13.Click += new System.EventHandler(this.play_v13_Click);
        	// 
        	// pause_v13
        	// 
        	this.pause_v13.BackColor = System.Drawing.Color.Transparent;
        	this.pause_v13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.pause_v13.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.pause_v13.Image = global::mp3dll.Properties.Resources.pausar;
        	this.pause_v13.Location = new System.Drawing.Point(110, 520);
        	this.pause_v13.Name = "pause_v13";
        	this.pause_v13.Size = new System.Drawing.Size(80, 42);
        	this.pause_v13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.pause_v13.TabIndex = 130;
        	this.pause_v13.TabStop = false;
        	this.pause_v13.Visible = false;
        	this.pause_v13.Click += new System.EventHandler(this.pause_v13_Click);
        	// 
        	// resume_v13
        	// 
        	this.resume_v13.BackColor = System.Drawing.Color.Transparent;
        	this.resume_v13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.resume_v13.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.resume_v13.Image = global::mp3dll.Properties.Resources.resume;
        	this.resume_v13.Location = new System.Drawing.Point(196, 520);
        	this.resume_v13.Name = "resume_v13";
        	this.resume_v13.Size = new System.Drawing.Size(80, 42);
        	this.resume_v13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.resume_v13.TabIndex = 129;
        	this.resume_v13.TabStop = false;
        	this.resume_v13.Visible = false;
        	this.resume_v13.Click += new System.EventHandler(this.resume_v13_Click);
        	// 
        	// cancel_v13
        	// 
        	this.cancel_v13.BackColor = System.Drawing.Color.Transparent;
        	this.cancel_v13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.cancel_v13.Cursor = System.Windows.Forms.Cursors.Hand;
        	this.cancel_v13.Image = global::mp3dll.Properties.Resources.cancel;
        	this.cancel_v13.Location = new System.Drawing.Point(282, 520);
        	this.cancel_v13.Name = "cancel_v13";
        	this.cancel_v13.Size = new System.Drawing.Size(80, 42);
        	this.cancel_v13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        	this.cancel_v13.TabIndex = 128;
        	this.cancel_v13.TabStop = false;
        	this.cancel_v13.Visible = false;
        	this.cancel_v13.Click += new System.EventHandler(this.cancel_v13_Click);
        	// 
        	// playlist
        	// 
        	this.playlist.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
			this.File,
			this.path});
        	this.playlist.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.playlist.ForeColor = System.Drawing.Color.RoyalBlue;
        	this.playlist.FullRowSelect = true;
        	this.playlist.GridLines = true;
        	this.playlist.Location = new System.Drawing.Point(20, 91);
        	this.playlist.MultiSelect = false;
        	this.playlist.Name = "playlist";
        	this.playlist.Size = new System.Drawing.Size(670, 339);
        	this.playlist.TabIndex = 115;
        	this.playlist.UseCompatibleStateImageBehavior = false;
        	this.playlist.View = System.Windows.Forms.View.Details;
        	this.playlist.Visible = false;
        	this.playlist.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.PlaylistColumnClick);
        	this.playlist.Click += new System.EventHandler(this.playlist_Click);
        	this.playlist.DoubleClick += new System.EventHandler(this.playlist_DoubleClick);
        	this.playlist.KeyDown += new System.Windows.Forms.KeyEventHandler(this.playlist_KeyDown);
        	this.playlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.playlist_KeyUp);
        	this.playlist.MouseUp += new System.Windows.Forms.MouseEventHandler(this.playlist_MouseUp);
        	// 
        	// File
        	// 
        	this.File.Text = "File";
        	this.File.Width = 400;
        	// 
        	// path
        	// 
        	this.path.Text = "Path";
        	this.path.Width = 800;
        	// 
        	// peak
        	// 
        	this.peak.Location = new System.Drawing.Point(21, 541);
        	this.peak.Maximum = 100;
        	this.peak.Name = "peak";
        	this.peak.Size = new System.Drawing.Size(669, 21);
        	this.peak.TabIndex = 77;
        	this.peak.Value = 0;
        	// 
        	// wave_out_volume
        	// 
        	this.wave_out_volume.Location = new System.Drawing.Point(1047, 338);
        	this.wave_out_volume.Maximum = 100;
        	this.wave_out_volume.Name = "wave_out_volume";
        	this.wave_out_volume.Size = new System.Drawing.Size(123, 18);
        	this.wave_out_volume.TabIndex = 76;
        	this.wave_out_volume.Value = 0;
        	this.wave_out_volume.Mouse += new amanda_progress.progressbar.NewMouseEvent(this.wave_out_volume_Mouse);
        	// 
        	// internal_volume
        	// 
        	this.internal_volume.Location = new System.Drawing.Point(1047, 362);
        	this.internal_volume.Maximum = 200;
        	this.internal_volume.Name = "internal_volume";
        	this.internal_volume.Size = new System.Drawing.Size(124, 18);
        	this.internal_volume.TabIndex = 75;
        	this.internal_volume.Value = 0;
        	this.internal_volume.Mouse += new amanda_progress.progressbar.NewMouseEvent(this.internal_volume_Mouse);
        	// 
        	// progressbar1
        	// 
        	this.progressbar1.Location = new System.Drawing.Point(21, 581);
        	this.progressbar1.Maximum = 10000;
        	this.progressbar1.Name = "progressbar1";
        	this.progressbar1.Size = new System.Drawing.Size(669, 21);
        	this.progressbar1.TabIndex = 74;
        	this.progressbar1.Value = 0;
        	this.progressbar1.Mouse += new amanda_progress.progressbar.NewMouseEvent(this.progressbar1_Mouse);
        	this.progressbar1.MouseEnter += new System.EventHandler(this.progressbar1_MouseEnter);
        	this.progressbar1.MouseLeave += new System.EventHandler(this.progressbar1_MouseLeave);
        	// 
        	// sample
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(1294, 708);
        	this.Controls.Add(this.play_v13);
        	this.Controls.Add(this.pause_v13);
        	this.Controls.Add(this.resume_v13);
        	this.Controls.Add(this.cancel_v13);
        	this.Controls.Add(this.play_v12);
        	this.Controls.Add(this.pause_v12);
        	this.Controls.Add(this.resume_v12);
        	this.Controls.Add(this.cancel_v12);
        	this.Controls.Add(this.select_v12);
        	this.Controls.Add(this.open_v12);
        	this.Controls.Add(this.button27);
        	this.Controls.Add(this.label22);
        	this.Controls.Add(this.sync_t);
        	this.Controls.Add(this.file_l);
        	this.Controls.Add(this.randon);
        	this.Controls.Add(this.button4);
        	this.Controls.Add(this.playlist);
        	this.Controls.Add(this.fs_400);
        	this.Controls.Add(this.fs_300);
        	this.Controls.Add(this.fs_by_heigth);
        	this.Controls.Add(this.fs_200);
        	this.Controls.Add(this.fs_50);
        	this.Controls.Add(this.background_p);
        	this.Controls.Add(this.default_w);
        	this.Controls.Add(this.no_draw);
        	this.Controls.Add(this.disable_video);
        	this.Controls.Add(this.info);
        	this.Controls.Add(this.button26);
        	this.Controls.Add(this.button25);
        	this.Controls.Add(this.dummyimage_p);
        	this.Controls.Add(this.dummy2_p);
        	this.Controls.Add(this.video_f_p);
        	this.Controls.Add(this.full_screen_b_);
        	this.Controls.Add(this.label21);
        	this.Controls.Add(this.button24);
        	this.Controls.Add(this.button23);
        	this.Controls.Add(this.button22);
        	this.Controls.Add(this.button21);
        	this.Controls.Add(this.button20);
        	this.Controls.Add(this.button19);
        	this.Controls.Add(this.button18);
        	this.Controls.Add(this.button17);
        	this.Controls.Add(this.width_t);
        	this.Controls.Add(this.button16);
        	this.Controls.Add(this.peak);
        	this.Controls.Add(this.wave_out_volume);
        	this.Controls.Add(this.internal_volume);
        	this.Controls.Add(this.progressbar1);
        	this.Controls.Add(this.button15);
        	this.Controls.Add(this.label13);
        	this.Controls.Add(this.track);
        	this.Controls.Add(this.label11);
        	this.Controls.Add(this.bits_per_sample);
        	this.Controls.Add(this.stereo_as_mono);
        	this.Controls.Add(this.button14);
        	this.Controls.Add(this.button13);
        	this.Controls.Add(this.label24);
        	this.Controls.Add(this.Hecho_in_Brasil);
        	this.Controls.Add(this.by_BW);
        	this.Controls.Add(this.button12);
        	this.Controls.Add(this.button11);
        	this.Controls.Add(this.button3);
        	this.Controls.Add(this.button1);
        	this.Controls.Add(this.morcego_error);
        	this.Controls.Add(this.filetowav);
        	this.Controls.Add(this.button10);
        	this.Controls.Add(this.label19);
        	this.Controls.Add(this.label18);
        	this.Controls.Add(this.label17);
        	this.Controls.Add(this.label16);
        	this.Controls.Add(this.label15);
        	this.Controls.Add(this.label14);
        	this.Controls.Add(this.label12);
        	this.Controls.Add(this.label1);
        	this.Controls.Add(this.label10);
        	this.Controls.Add(this.label9);
        	this.Controls.Add(this.label8);
        	this.Controls.Add(this.label7);
        	this.Controls.Add(this.label6);
        	this.Controls.Add(this.label5);
        	this.Controls.Add(this.label4);
        	this.Controls.Add(this.loop);
        	this.Controls.Add(this.label3);
        	this.Controls.Add(this.waveout);
        	this.Controls.Add(this.priority);
        	this.Controls.Add(this.label2);
        	this.Controls.Add(this.filename);
        	this.Controls.Add(this.menu);
        	this.Controls.Add(this.video_p);
        	this.Controls.Add(this.pixel_l);
        	this.Controls.Add(this.width_minus_minus);
        	this.Controls.Add(this.width_plu_plus);
        	this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        	this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        	this.MainMenuStrip = this.menu;
        	this.Name = "sample";
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        	this.Text = "Form1";
        	this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.sample_FormClosing);
        	this.Load += new System.EventHandler(this.Form1_Load);
        	this.Move += new System.EventHandler(this.sample_Move);
        	this.menu.ResumeLayout(false);
        	this.menu.PerformLayout();
        	((System.ComponentModel.ISupportInitialize)(this.play_v12)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.pause_v12)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.resume_v12)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.cancel_v12)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.select_v12)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.open_v12)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.background_p)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.dummyimage_p)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.dummy2_p)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.video_f_p)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.video_p)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.play_v13)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.pause_v13)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.resume_v13)).EndInit();
        	((System.ComponentModel.ISupportInitialize)(this.cancel_v13)).EndInit();
        	this.ResumeLayout(false);
        	this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer main_timer;
        private System.Windows.Forms.TextBox filename;
        private System.Windows.Forms.OpenFileDialog of1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox priority;
        private System.Windows.Forms.ComboBox waveout;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox loop;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox filetowav;
        private System.Windows.Forms.ListBox morcego_error;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.LinkLabel by_BW;
        private System.Windows.Forms.LinkLabel Hecho_in_Brasil;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.CheckBox stereo_as_mono;
        private System.Windows.Forms.Label bits_per_sample;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox track;
        private System.Windows.Forms.Button button15;
        private amanda_progress.progressbar progressbar1;
        private System.Windows.Forms.Timer convert_timer;
        private amanda_progress.progressbar internal_volume;
        private amanda_progress.progressbar wave_out_volume;
        private amanda_progress.progressbar peak;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox width_t;
        private System.Windows.Forms.PictureBox video_p;
        private System.Windows.Forms.PictureBox video_f_p;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button full_screen_b;
        private System.Windows.Forms.Button full_screen_b_;
        private System.Windows.Forms.PictureBox dummyimage_p;
        private System.Windows.Forms.PictureBox dummy2_p;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label info;
        private System.Windows.Forms.Timer fs;
        private System.Windows.Forms.Timer esconde_t;
        private System.Windows.Forms.CheckBox disable_video;
        private System.Windows.Forms.CheckBox no_draw;
        private System.Windows.Forms.Button default_w;
        private System.Windows.Forms.PictureBox background_p;
        private System.Windows.Forms.Timer cancel_imer;
        private System.Windows.Forms.Label pixel_l;
        private System.Windows.Forms.Button width_plu_plus;
        private System.Windows.Forms.Button width_minus_minus;
        private System.Windows.Forms.Timer weird_timer;
        private System.Windows.Forms.Button fs_50;
        private System.Windows.Forms.Button fs_200;
        private System.Windows.Forms.Button fs_by_heigth;
        private System.Windows.Forms.Button fs_300;
        private System.Windows.Forms.Button fs_400;
        private System.Windows.Forms.ListView playlist;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ColumnHeader File;
        private System.Windows.Forms.CheckBox randon;
        private System.Windows.Forms.ColumnHeader path;
        private System.Windows.Forms.Label file_l;
        private System.Windows.Forms.TextBox sync_t;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.PictureBox open_v12;
        private System.Windows.Forms.PictureBox select_v12;
        private System.Windows.Forms.PictureBox cancel_v12;
        private System.Windows.Forms.PictureBox resume_v12;
        private System.Windows.Forms.PictureBox pause_v12;
        private System.Windows.Forms.PictureBox play_v12;
        private System.Windows.Forms.PictureBox play_v13;
        private System.Windows.Forms.PictureBox pause_v13;
        private System.Windows.Forms.PictureBox resume_v13;
        private System.Windows.Forms.PictureBox cancel_v13;
    }
}

