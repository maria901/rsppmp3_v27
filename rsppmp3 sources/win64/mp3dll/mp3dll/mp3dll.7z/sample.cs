   /*
    Copyright (C) <2020>  <BinaryWork Corp.>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU GENERAL PUBLIC LICENSE
	and GNU LESSER GENERAL PUBLIC LICENSE along with this program.  
	If not, see <http://www.gnu.org/licenses/>.
    
        support: http://nomade.sourceforge.net/?AR=true&ar_debug=1
    
	direct programmers e-mails:
	Ricardo: arsoftware25@gmail.com  ricardo@arsoftware.net.br contato@locacaodiaria.com.br
	 Amanda: arsoftware10@gmail.com  amanda@arsoftware.net. br vendas@locacaodiaria.com.b r
	
	immediate contact(for a very fast answer) WhatsApp
	(+55)41 9627 1708 - it is always on
*/

/*

this sample application requires windows 7 or above
sharpdevelop 5 or visual studio 17

it will disable standby/hibernation and will avoid the monitor to turning off during playback

 */

using System;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace mp3dll
{
	/// <summary>
	/// Form1
	/// </summary>
	public partial class sample : Form
	{
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			MP3.dprintf(keyData.ToString());

			if ("Return" == keyData.ToString())
			{
				if (MP3.is_playlist)
				{
					int loop_ = 0;
					if (CheckState.Checked == loop.CheckState)
					{
						loop_ = 1;
					}
					
					main_timer.Enabled = false;
					MP3.Play(number, MP3.wide2utf8(MP3.the_filename), loop_, int.Parse(track.Text),
					         video_p.Handle.ToInt64(),
					         video_f_p.Handle.ToInt64(),
					         video_p.Width,
					         video_p.Height,
					         the_ratio,
					         video_p.Left,
					         video_p.Top);
					playlist.Visible = false;
					main_timer.Enabled = true;
				}
				return true;
			}
			if ("F8" == keyData.ToString())
			{
				int val;

				MP3.GetSettings("volume_v11", message, "100");

				val = int.Parse(message.ToString());

				val -= 5;
				if (val < 0)
				{
					val = 0;
				}
				internal_volume.Value = val;
				MP3.InternalVolume(number, val);
				MP3.SaveSettings("volume_v11", val.ToString());

			}
			if ("F9" == keyData.ToString())
			{
				int val;

				MP3.GetSettings("volume_v11", message, "100");

				val = int.Parse(message.ToString());

				val += 5;
				if (val > 200)
				{
					val = 200;
				}
				internal_volume.Value = val;
				MP3.InternalVolume(number, val);
				MP3.SaveSettings("volume_v11", val.ToString());

			}
			if ("Escape" == keyData.ToString())
			{

				fullscreen_state_ = 0;
				video_p_MouseClick(null, null);

			}
			if ("F11" == keyData.ToString())
			{
				width_plu_plus_Click(null, null);
			}
			if ("F12" == keyData.ToString())
			{
				width_minus_minus_Click(null, null);
			}
			if ("ShiftKey, Shift, Alt" == keyData.ToString())
			{
				if (0 == fullscreen_state_)
				{
					fullscreen_state_ = 1;
					default_w_Click(null, null);
				}
				else
				{
					fullscreen_state_ = 0;
					video_p_MouseClick(null, null);
				}
				return true;
			}
			if ("S, Control" == keyData.ToString())
			{

				button8_Click(null, null);
				return true;

			}
			if ("Return, Alt" == keyData.ToString())
			{

				if (0 == fullscreen_state_)
				{
					fullscreen_state_ = 1;
					button25_Click(null, null);
				}
				else
				{
					fullscreen_state_ = 0;
					video_p_MouseClick(null, null);
				}

				return true;
			}

			if ("P, Control" == keyData.ToString())
			{

				if (0 == pause_state_)
				{
					pause_state_ = 1;
					MP3.PlaybackPause(number);
				}
				else
				{
					pause_state_ = 0;
					MP3.PlaybackResume(number);
				}

				return true;
			}

			switch (keyData)
			{

				case Keys.Space:

					if (0 == pause_state_)
					{
						pause_state_ = 1;
						MP3.PlaybackPause(number);
					}
					else
					{
						pause_state_ = 0;
						MP3.PlaybackResume(number);
					}

					break;//return true; it will avoid the absence of space in the textboxes, fixed
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
		private ListViewColumnSorter lvwColumnSorter;
		/// <summary>
		/// amanda constructor
		/// </summary>
		public sample()
		{
			InitializeComponent();
			lvwColumnSorter = new ListViewColumnSorter();
			this.playlist.ListViewItemSorter = lvwColumnSorter;
			this.WindowState = FormWindowState/* by ricardo */.Maximized;
		}

		mp3dll.avoid_standby disable_standby = new  mp3dll.avoid_standby();
		
		private void timer1_Tick(object sender, EventArgs e)
		{
			/**
			 * media file not loaded yet
			 */
			if (-1 == MP3.SampleRate(number))//
			{
				label16.Text = "Media type: Detecting media...";
				label5.Text = "Sample rate";
				label8.Text = "Channels";
				label7.Text = "Bitrate";
				label6.Text = "Mode";
				label9.Text = "Normalization";
				label1.Text = "Position";
				label15.Text = "Milliseconds";
				label1.Text = "Position";
				label17.Text = "Normalize factor";
				label14.Text = "Time position";
				label12.Text = "Time";
				label24.Text = "Remaining time";
				bits_per_sample.Text = "Bits per sample";

				info.Text = "Video info";
				pixel_l.Text = "Pixel Format";
				return;
			}
			
			
			if(0==already&&1==MP3.GetSyncStatus(number))
			{
				morcego_error.Items.Add("Audio and video sync lost" );
				morcego_error.SelectedIndex = morcego_error.Items.Count - 1;
				already=1;
			}
			
			if (MP3.is_playlist)
			{
				file_l.Text = playlist.Items[MP3.playlist_index].SubItems[0].Text;
			}
			else
			{
				file_l.Text = "";
			}
			MP3.GetPixelFormat____(number, message);
			pixel_l.Text = "Pixel Format: " + message.ToString();

			MP3.GetVideoInfo(number, message);
			info.Text = "Video info: " + message.ToString();

			int ret2 = MP3.IntReturn(number);

			//////////////////section to update the playback status

			if (1000 == ret2)
			{
				if (1 == open_flag)
				{
					label4.Text = "Status: stop";
				}
				else
				{
					label4.Text = "Status: play";
				}
			}

			if (1001 == ret2)
			{
				label4.Text = "Status: paused";
			}

			if (ret2 < 1000)
			{
				label4.Text = "Status: stop";
			}
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////

			label5.Text = "Sample rate: " + MP3.SampleRate(number).ToString();
			label8.Text = "Channels: " + MP3.Channels(number).ToString();

			bits_per_sample.Text = "Bits per sample " + MP3.Bits_per_Sample(number);

			label7.Text = "Bitrate: " + MP3.GetBitrate(number).ToString();

			MP3.GetMpegMode(number, time);
			label6.Text = "Mode: " + time.ToString();

			if (1 == MP3.IsUsingNormalization(number))
			{
				label9.Text = "Normalization: true";
			}
			else
			{
				label9.Text = "Normalization: false";
			}

			label1.Text = "Position: " + MP3.GetTimeMilliseconds(number).ToString();

			label15.Text = "Milliseconds: " + MP3.GetLengthMilliseconds(number).ToString();

			MP3.GetMediaInformation(number, time);
			label16.Text = "Media type: " + time.ToString();

			MP3.NormalizationFactor(number, time);

			label17.Text = "Normalize factor: " + time.ToString();

			peak.Value = MP3.GetPeak(number);

			Position = MP3.PlayBackPosition_10000(number);

			progressbar1.Value = Position;

			MP3.GetTimeString(number, time);

			label14.Text = "Time position " + time.ToString();

			this.Text = time.ToString() + " - " + nome_da_dll;

			MP3.GetLengthString(number, time);

			label12.Text = "Time " + time.ToString();

			MP3.Alladin_GetRemainingTime(number, _data_);

			label24.Text = "Remaining time: " + _data_.ToString();

			int ret;

			ret = MP3.IntReturn(number);

			if (999 > ret)
			{
				disable_standby.EnableConstantDisplayAndPower(false);
				label10.Text = "Finished event raised";
				main_timer.Enabled = false;
				if (0 != ret)
				{

					MP3.GetErrorString(number, ret, message);
					morcego_error.Items.Add(message.ToString());
					morcego_error.SelectedIndex = morcego_error.Items.Count - 1;

				}

				if (MP3.is_playlist)
				{
					MP3.playlist_index++;
					if (MP3.is_shuffle)
					{
						if (MP3.is_shuffle)
						{
							int v = MP3.get_rand(0, playlist.Items.Count - 1);
							MP3.playlist_index = v;
						}
					}
					else
					{
						if (MP3.playlist_index == playlist.Items.Count)
						{
							MP3.playlist_index = 0;
						}
					}
					int loop_ = 0;
					if (CheckState.Checked == loop.CheckState)
					{
						loop_ = 1;
					}
					playlist.Items[MP3.playlist_index].Selected=true;
					playlist.Items[MP3.playlist_index].EnsureVisible();
					playlist.Visible = false;
					file_l.Text = playlist.Items[MP3.playlist_index].SubItems[0].Text;
					ret = MP3.Play(number, MP3.wide2utf8(playlist.Items[MP3.playlist_index].SubItems[1].Text), loop_, int.Parse(track.Text),
					               video_p.Handle.ToInt64(),
					               video_f_p.Handle.ToInt64(),
					               video_p.Width,
					               video_p.Height,
					               the_ratio,
					               video_p.Left,
					               video_p.Top);
					disable_standby.EnableConstantDisplayAndPower(true);
					
					main_timer.Enabled = true;
				}
			}
		}
		private void button2_Click(object sender, EventArgs e)
		{
			of1.Filter = "All files (*.*)|*.*";
			of1.FileName = "";
			DialogResult dlg = of1.ShowDialog();

			if (dlg == DialogResult.OK)
			{
				filename.Text = of1.FileName;
			}
		}

		int disable = 0;

		StringBuilder settings = new StringBuilder(300*6);

		StringBuilder message = new StringBuilder(300*6);

		StringBuilder time = new StringBuilder(300);

		morcego_ratio the_ratio = morcego_ratio.BE_AUTO_______;

		string copia = "";

		int slider_original_location;

		int slider_width;

		int oldposition = 0;

		StringBuilder _data_ = new StringBuilder(300);

		int Position = 0;

		int pause_state_ = 0;
		int fullscreen_state_ = 0;

		long number = MP3.number;
		string nome_da_dll;
		int already=0;
		private void Form1_Load(object sender, EventArgs e)
		{
						
			int ret;
			this.Top = 0;

			MP3.ControlName(message);
			nome_da_dll = message.ToString();

			video_p.Image = dummyimage_p.Image;
			video_f_p.Image = dummy2_p.Image;
			track.Items.Add("1");
			track.Text = "1";

			MP3.GetSettings("be_effect", settings, "0");
			if ("1"==settings.ToString())
			{
				MP3.GetSettings("be_effect_val", settings, "0");
				MP3.BE_Special_Wav_Effect(number, 1, int.Parse(settings.ToString ()));
			}
			else
			{
				MP3.GetSettings("be_effect_val", settings, "0");
				MP3.BE_Special_Wav_Effect(number, 0, int.Parse(settings.ToString()));
			}

			MP3.GetSettings("randon", settings, "0");

			MP3.is_shuffle = true;
			randon.CheckState = CheckState.Checked;
			if ("0" == settings.ToString())
			{
				MP3.is_shuffle = false;
				randon.CheckState = CheckState.Unchecked;
			}

			MP3.GetSettings("width", settings, "0");

			width_t.Text = settings.ToString();

			MP3.GetSettings("replaygain", settings, "0");

			MP3.EnableOnTheFlyVolumeNormalization(number, int.Parse(settings.ToString()));

			MP3.GetSettings("wav_out_vol", settings, "100");
			int value = int.Parse(settings.ToString());
			MP3.SetVolumeGain(number, value);

			wave_out_volume.Value = value;

			MP3.GetSettings("play_as_mp3", settings, "0");

			MP3.GetSettings("stereo_as_mono", settings, "0");

			/*you are not in Kansas anymore*/
			if ("0" == settings.ToString())
			{
				stereo_as_mono.CheckState = CheckState.Unchecked;
				MP3.BucaneiroPlayStereoAsMono(number, 0);

			}
			else
			{
				stereo_as_mono.CheckState = CheckState.Checked;
				MP3.BucaneiroPlayStereoAsMono(number, 1);

			}

			MP3.GetSettings("volume_v11", settings, "100");
			internal_volume.Value = int.Parse(settings.ToString());

			MP3.InternalVolume(number, internal_volume.Value);

			MP3.GetSettings("encryption", settings, "0");


			StringBuilder euo = new StringBuilder(300);

			MP3.ControlName(euo);
			this.Text = euo.ToString() + " - Sample Project";

			copia = this.Text;

			MP3.GetSettings("filename", settings, "");
			filename.Text = MP3.utf82wide(settings.ToString());

			MP3.GetSettings("loop", settings, "0");

			if ("0" == settings.ToString())
			{
				loop.CheckState = CheckState.Unchecked;
			}
			else
			{
				loop.CheckState = CheckState.Checked;
			}

			priority.Items.Add("IDLE");
			priority.Items.Add("NORMAL");
			priority.Items.Add("HIGH");

			MP3.GetSettings("priority", settings, "1");

			priority.SelectedIndex = int.Parse(settings.ToString());

			ret = MP3.GetNumberofWaveOutDevices(number);

			if (0 == ret)
			{
				MessageBox.Show("No soundcard installed in the system");
				waveout.Text = "<no soundcard>";
			}
			else
			{
				disable = 1;

				int l;

				for (l = 0; l < ret; l++)
				{
					MP3.GetWaveOutDevicesName(number, l, settings);
					waveout.Items.Add(settings.ToString());
				}
				MP3.GetSettings("waveout", settings, "0");
				waveout.SelectedIndex = int.Parse(settings.ToString());

				disable = 0;
			}
			slider_original_location = progressbar1.Left;
			slider_width = progressbar1.Width;
			
		}

		private void nobuffer_MouseUp(object sender, MouseEventArgs e)
		{
		}

		private void smart_MouseUp(object sender, MouseEventArgs e)
		{
		}

		private void limit_TextChanged(object sender, EventArgs e)
		{

		}

		private void waveout_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (disable > 0)
			{
				return;
			}
			MP3.dprintf("aqui");
			MP3.SaveSettings("waveout", waveout.SelectedIndex.ToString());

		}

		private void loop_MouseUp(object sender, MouseEventArgs e)
		{

			if (CheckState.Checked == loop.CheckState)
			{
				MP3.SaveSettings("loop", "1");
			}
			else
			{
				MP3.SaveSettings("loop", "0");
			}

		}

		private void button4_Click(object sender, EventArgs e)
		{
			int ret;
			already=0;
			playlist.Visible = false;
			main_timer.Enabled = false;
			pause_state_ = 0;
			video_p.Image = dummy2_p.Image;
			video_f_p.Image = dummy2_p.Image;
			open_flag = 0;
			label10.Text = "Playing";
			MP3.GetSettings("replaygain", settings, "0");
			MP3.EnableOnTheFlyVolumeNormalization(number, int.Parse(settings.ToString()));


			MP3.SetWaveOutDevice(number, waveout.SelectedIndex);
			MP3.is_playlist = false;
			int loop_ = 0;
			if (CheckState.Checked == loop.CheckState)
			{
				loop_ = 1;
			}
			int r;
			r = MP3.Is_WPL_Playlist(number, MP3.wide2utf8(filename.Text));
			MP3.dprintf("r "+r);
			if (0 == r)
			{
				ret = MP3.Play(number, MP3.wide2utf8(filename.Text), loop_, int.Parse(track.Text),
				               video_p.Handle.ToInt64(),
				               video_f_p.Handle.ToInt64(),
				               video_p.Width,
				               video_p.Height,
				               the_ratio,
				               video_p.Left,
				               video_p.Top);
			}
			else
			{

				playlist.Items.Clear();
			devolta:
				;
				r = MP3.GetPlaylistFiles(number, message);

				if (1 == r)
				{

					MP3.get_filename
						(
							message.ToString(),
							settings
						)
						;

					var coisa = playlist.Items.Add(MP3.utf82wide(this.settings.ToString()));
					coisa.SubItems.Add(MP3.utf82wide(message.ToString()));
					goto devolta;
				}
				MP3.is_playlist = true;
				MP3.playlist_index = 0;

				if (MP3.is_shuffle)
				{
					int v = MP3.get_rand(0, playlist.Items.Count - 1);
					MP3.playlist_index = v;
				}
				playlist.Visible = true;
				playlist.Items[MP3.playlist_index].Selected = true;
				playlist.Items[MP3.playlist_index].EnsureVisible();
				playlist.Visible = false;
				file_l.Text = playlist.Items[MP3.playlist_index].SubItems[0].Text;
				ret = MP3.Play(number, MP3.wide2utf8(playlist.Items[MP3.playlist_index].SubItems[1].Text), loop_, int.Parse(track.Text),
				               video_p.Handle.ToInt64(),
				               video_f_p.Handle.ToInt64(),
				               video_p.Width,
				               video_p.Height,
				               the_ratio,
				               video_p.Left,
				               video_p.Top);
			}

			main_timer.Enabled = true;
			//-1 == ret then last call was not finished loading the media file yet
			
			disable_standby.EnableConstantDisplayAndPower(true);
		}


		private void filename_TextChanged(object sender, EventArgs e)
		{
			MP3.SaveSettings("filename", MP3.wide2utf8(filename.Text));
		}

		int open_flag = 0;
		private void button6_Click(object sender, EventArgs e)
		{
			int ret;
			already=0;
			playlist.Visible = false;
			main_timer.Enabled = false;
			pause_state_ = 0;
			video_p.Image = dummy2_p.Image;
			video_f_p.Image = dummy2_p.Image;
			open_flag = 0;
			label10.Text = "Playing";
			MP3.GetSettings("replaygain", settings, "0");
			MP3.EnableOnTheFlyVolumeNormalization(number, int.Parse(settings.ToString()));


			MP3.SetWaveOutDevice(number, waveout.SelectedIndex);
			MP3.is_playlist = false;
			int loop_ = 0;
			if (CheckState.Checked == loop.CheckState)
			{
				loop_ = 1;
			}
			int r;
			r = MP3.Is_WPL_Playlist(number, MP3.wide2utf8(filename.Text));

			if (0 == r)
			{
				ret = MP3.Open(number, MP3.wide2utf8(filename.Text), loop_, int.Parse(track.Text),
				               video_p.Handle.ToInt64(),
				               video_f_p.Handle.ToInt64(),
				               video_p.Width,
				               video_p.Height,
				               the_ratio,
				               video_p.Left,
				               video_p.Top);
			}
			else
			{

				playlist.Items.Clear();
			devolta:
				;
				r = MP3.GetPlaylistFiles(number, message);

				if (1 == r)
				{

					MP3.get_filename
						(
							message.ToString(),
							settings
						)
						;

					ListViewItem coisa = playlist.Items.Add(MP3.utf82wide(settings.ToString()));
					coisa.SubItems.Add(MP3.utf82wide(message.ToString()));
					goto devolta;
				}
				MP3.is_playlist = true;
				MP3.playlist_index = 0;

				if (MP3.is_shuffle)
				{
					int v = MP3.get_rand(0, playlist.Items.Count - 1);
					MP3.playlist_index = v;
				}
				playlist.Visible = true;
				playlist.Items[MP3.playlist_index].Selected = true;
				playlist.Items[MP3.playlist_index].EnsureVisible();
				playlist.Visible = false;
				file_l.Text = playlist.Items[MP3.playlist_index].SubItems[0].Text;
				ret = MP3.Open(number, MP3.wide2utf8(playlist.Items[MP3.playlist_index].SubItems[1].Text), loop_, int.Parse(track.Text),
				               video_p.Handle.ToInt64(),
				               video_f_p.Handle.ToInt64(),
				               video_p.Width,
				               video_p.Height,
				               the_ratio,
				               video_p.Left,
				               video_p.Top);
			}

			main_timer.Enabled = true;
			//-1 == ret then last call was not finished loading the media file yet
			disable_standby.EnableConstantDisplayAndPower(true);
			
		}

		private void morcego_pass_video_information()
		{

			if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2, if not the internals of the DLL will fix it to you
			{
				video_p.Height--;
			}
			if (1 == video_p.Width % 2)
			{
				video_p.Width--;
			}

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button7_Click(object sender, EventArgs e)
		{
			MP3.PlaybackPause(number);
			pause_state_ = 1;
			disable_standby.EnableConstantDisplayAndPower(false);
		}

		private void button5_Click(object sender, EventArgs e)
		{
			MP3.PlaybackResume(number);
			pause_state_ = 0;
			disable_standby.EnableConstantDisplayAndPower(true);
		}

		private void button8_Click(object sender, EventArgs e)
		{
			main_timer.Enabled = false;
			MP3.is_playlist = false;
			MP3.PlaybackCancel(number);
			label4.Text = "Status: stop";
			label10.Text = "Cancel";
			peak.Value = 0;

			video_p.Image = dummyimage_p.Image;
			video_f_p.Image = dummy2_p.Image;
			video_f_p.Top = video_p.Top + 100;
			video_f_p.Height = 30;
			video_f_p.Width = 20;
			video_f_p.Left = 80;
			
			
			disable_standby.EnableConstantDisplayAndPower(false);
		}

		private void priority_SelectedIndexChanged(object sender, EventArgs e)
		{
			MP3.SaveSettings("priority", priority.SelectedIndex.ToString());
			if ("IDLE" == priority.Text)
			{
				MP3.dprintf("set to idle\n");
				MP3.SetPriority(number, 0);
			}
			if ("NORMAL" == priority.Text)
			{
				MP3.SetPriority(number, 1);
			}
			if ("HIGH" == priority.Text)
			{
				MP3.SetPriority(number, 2);
			}
		}

		private void button10_Click(object sender, EventArgs e)
		{

			/* why the rest of the code is not so easy to write like this...*/
			label10.Text = "Converting...";
			this.Refresh();

			StringBuilder err_msg = new StringBuilder(300);

			select_wav_mode eu = new select_wav_mode();
			eu.ShowDialog();

			progressbar1.Value = (0);

			if (0 != MP3.ConvertMP3ToWavExtended(number, MP3.wide2utf8(filename.Text),
			                                     MP3.wide2utf8(filetowav.Text), MP3.wave_mode,
			                                     int.Parse(track.Text)))
			{

				morcego_error.Items.Add(5.ToString() + " - Decoder is in use");
				morcego_error.SelectedIndex = morcego_error.Items.Count - 1;

			}

			convert_timer.Enabled = true;

		}

		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			MP3.About();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			equalizer eu = new equalizer();
			eu.Show();			
		}

		private void button3_Click(object sender, EventArgs e)
		{
			normalize eu = new normalize();
			eu.Show();
		}

		private void button11_Click(object sender, EventArgs e)
		{
			spectrum eu = new spectrum();
			eu.Show();
		}

		private void button12_Click(object sender, EventArgs e)
		{

			int i;

			for (i = 0; i < 150; i++)
			{
				StringBuilder data_ = new StringBuilder(300);

				MP3.Generate_ID3v1Genre(number, i, data_);
			}

		}

		private void button12_Click_1(object sender, EventArgs e)
		{
			DebugInformation eu = new DebugInformation();
			eu.Show();
		}

		private void button13_Click(object sender, EventArgs e)
		{
			wave_effects eu = new wave_effects();
			eu.Show();
		}
		private void button14_Click(object sender, EventArgs e)
		{

			internal_volume.Value = 100;
			MP3.InternalVolume(number, internal_volume.Value);
			MP3.SaveSettings("volume_v11", internal_volume.Value.ToString());

		}
		private void stereo_as_mono_MouseUp(object sender, MouseEventArgs e)
		{

			if (CheckState.Unchecked == stereo_as_mono.CheckState)
			{

				MP3.SaveSettings("stereo_as_mono", "0");
				MP3.BucaneiroPlayStereoAsMono(number, 0);

			}
			else
			{
				MP3.SaveSettings("stereo_as_mono", "1");
				MP3.BucaneiroPlayStereoAsMono(number, 1);
			}

		}

		private void button15_Click(object sender, EventArgs e)
		{
			int ret;
			ret = MP3.GetNumberOfAudioTracks(number, MP3.wide2utf8(filename.Text), message);
			if (ret < 0)
			{
				morcego_error.Items.Add(ret + " - " + message.ToString());
				morcego_error.SelectedIndex = morcego_error.Items.Count - 1;
			}
			else
			{

				if (0 == ret)
				{
					///MP3.dprintf("primeiro\n");
					track.Text = "1";//default to track 1
				}
				else
				{
					////MP3.dprintf("segundo\n");
					track.Items.Clear();
					for (int i = 0; i < ret; i++)
					{
						track.Items.Add((i + 1).ToString());
					}
					track.Text = "1";
				}

			}
		}

		private void convert_timer_Tick(object sender, EventArgs e)
		{
			int finished;
			int percent;
			int returnvalue;
			MP3.GetConversionInfo(number, out percent, out finished, out returnvalue, message);
			progressbar1.Value = (percent * 100);
			if (0 != finished)
			{
				if (0 != returnvalue)
				{
					morcego_error.Items.Add(returnvalue.ToString() + " - " + message.ToString());
					morcego_error.SelectedIndex = morcego_error.Items.Count - 1;
				}
				label10.Text = "Finished...";
				convert_timer.Enabled = false;
				progressbar1.Value = 10000;
			}
			return;
		}

		private void progressbar1_Mouse(amanda_progress.progressbar.ExtendedMouseEvent e)
		{
			MP3.SeekTo_10000(number, e.Value);
		}
		
		private void internal_volume_Mouse(amanda_progress.progressbar.ExtendedMouseEvent e)
		{
			internal_volume.Value = e.Value;
			MP3.InternalVolume(number, e.Value);
			MP3.SaveSettings("volume_v11", e.Value.ToString());
		}

		private void wave_out_volume_Mouse(amanda_progress.progressbar.ExtendedMouseEvent e)
		{
			wave_out_volume.Value = e.Value;
			MP3.SetVolumeGain(number, e.Value);
			MP3.SaveSettings("wav_out_vol", e.Value.ToString());
		}

		private void button16_Click(object sender, EventArgs e)
		{
			id3tag morcego = new id3tag(filename.Text.Trim());
			morcego.Show();
		}

		private void sample_FormClosing(object sender, FormClosingEventArgs e)
		{
			main_timer.Enabled = false;
			MP3.PlaybackCancel(number);
			MP3.BE_CloseDecoder(ref number);
		}

		private void button17_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_AUTO_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void morcego_adjust_ratio()
		{
			if (MP3.loading_file)
			{
				MP3.dprintf("trying to load a file while the load function have not returned yet");
				return;
			}
			MP3.loading_file = true;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);
			if (MP3.IntReturn(number) > 999)
			{

				MP3.PlaybackCancel(number);

				button6_Click(null, null);

				while (-1 == MP3.SampleRate(number))
				{
					Application.DoEvents();

					Thread.Sleep(50);
				}


				MP3.SeekTo_AV_TIME_BASE(number, position);
				MP3.PlaybackResume(number);
			}
			MP3.loading_file = false;
		}

		private void button24_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_5x4_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button23_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_16x9_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button22_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_4x3_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button21_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_2_21x1_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button20_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_2_35x1_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button19_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_2_39x1_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button18_Click(object sender, EventArgs e)
		{
			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_1x1_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button25_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;
				fullscreen_state_ = 1;

				MP3.is_full_screen = true;

				background_p.Visible = true;
				background_p.Width = this.Width;
				background_p.Height = this.Height;
				background_p.Top = 0;
				background_p.Left = 0;
				background_p.BringToFront();

				video_p.Width = this.Width;

				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				video_p.Height = Screen.PrimaryScreen.Bounds.Height;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.Top = 0;
				video_p.Left = 0;
				video_p.BringToFront();
				weird_timer.Enabled = true;
				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;

			}
		}

		private void video_p_MouseClick(object sender, MouseEventArgs e)
		{
			MP3.ShowCursor_(1);
			background_p.Visible = false;
			weird_timer.Enabled = false;
			progressbar1.Width = slider_width;
			progressbar1.Left = slider_original_location;
			progressbar1.Top = 581;
			fullscreen_state_ = 0;
			this.FormBorderStyle = FormBorderStyle.Sizable;
			this.WindowState = FormWindowState.Normal;
			if (MP3.is_full_screen == true)
			{

				fs.Enabled = false;
				esconde_t.Enabled = false;

				bool flag = false;
				play_v13
					.Visible = flag;
				pause_v13
					.Visible = flag;
				resume_v13 .Visible = flag;
				cancel_v13
					.Visible = flag;

				MP3.is_full_screen = false;
				this.Text = copia;

				video_p.Left = 20;
				video_p.Top = 92;
				video_p.Width = 670;
				video_p.Height = 338;

				double position = MP3.PlayBackPosition_AV_TIME_BASE(number);
				if (MP3.IntReturn(number) > 999)
				{

					video_p.BringToFront();

					MP3.PassWindowInformation
						(
							number,
							video_p.Handle.ToInt64(),
							video_f_p.Handle.ToInt64(),
							video_p.Width,
							video_p.Height,
							the_ratio,
							video_p.Left,
							video_p.Top
						)
						;
				}
				else
				{

					video_p.Image = dummyimage_p.Image;
					video_f_p.Image = dummy2_p.Image;
					video_f_p.Top = video_p.Top + 100;
					video_f_p.Height = 30;
					video_f_p.Width = 20;
					video_f_p.Left = 80;

				}
			}
		}

		private void video_f_p_MouseClick(object sender, MouseEventArgs e)
		{
			video_p_MouseClick(null, null);
		}

		private void sample_Move(object sender, EventArgs e)
		{

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;

			return;
		}

		private void button26_Click(object sender, EventArgs e)
		{

			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_16x10_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void button25_Click_1(object sender, EventArgs e)
		{

			MP3.adjusted_ratio = 0;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);
			the_ratio = morcego_ratio.BE_2_50x1_______;

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;
		}

		private void fs_Tick(object sender, EventArgs e)
		{
			fs.Interval = 4000;
			if (MP3.disabled)
			{
				return;
			}
			if (MP3.is_full_screen == true)
			{

				play_v13
					.Visible = true;
				pause_v13
					.Visible = true;
				resume_v13
					.Visible = true;
				cancel_v13
					.Visible = true;

				play_v13
					.BringToFront();
				pause_v13
					.BringToFront();
				resume_v13
					.BringToFront();
				cancel_v13
					.BringToFront();
				progressbar1.BringToFront();

				{

					MP3.ShowCursor_(0);

					if (50 != esconde_t.Interval)
					{
						esconde_t.Enabled = false;
						esconde_t.Interval = 3000;
						esconde_t.Enabled = true;
					}



				}
			}
			else
			{
				MP3.ShowCursor_(1);
				fs.Enabled = false;
			}
		}

		private void video_p_MouseMove(object sender, MouseEventArgs e)
		{

			show_constrols(e);

		}

		private void show_constrols(MouseEventArgs e)
		{


			if (oldposition != e.X)
			{
				play_v13
					.BringToFront();
				pause_v13
					.BringToFront();
				resume_v13
					.BringToFront();
				cancel_v13
					.BringToFront();
				progressbar1.BringToFront();

				MP3.ShowCursor_(1);
				if (MP3.is_full_screen)
				{

					fs.Enabled = false;
					fs.Enabled = true;
					play_v13
						.Top = 536;
					pause_v13
						.Top = 536;
					resume_v13
						.Top = 536;
					cancel_v13
						.Top = 536;
					progressbar1.Top = 581;
					esconde_t.Enabled = false;
					esconde_t.Interval = 3000;

				}
				oldposition = e.X;
			}
		}

		private void video_f_p_MouseMove(object sender, MouseEventArgs e)
		{
			show_constrols(e);
		}

		private void play2_b_Click(object sender, EventArgs e)
		{
			already=0;
			MP3.is_full_screen = true;
			fs.Enabled = true;
			MP3.PlaybackCancel(number);

			video_p.Width = this.Width;

			progressbar1.Width = this.Width - 46;

			int val = (this.Width - progressbar1.Width) / 2;

			progressbar1.Left = val;

			video_p.Height = this.Height;

			if (1 == video_p.Height % 2)
			{
				video_p.Height--;
			}
			if (1 == video_p.Width % 2)
			{
				video_p.Width--;
			}

			video_p.Top = 0;
			video_p.Left = 0;
			video_p.BringToFront();
			button6_Click(null, null);

			while (-1 == MP3.SampleRate(number))
			{
				Application.DoEvents();

				Thread.Sleep(50);
			}


			MP3.PlaybackResume(number);
			play_v13
				.Visible = true;
			pause_v13
				.Visible = true;
			resume_v13
				.Visible = true;
			cancel_v13
				.Visible = true;

			play_v13
				.BringToFront();
			pause_v13
				.BringToFront();
			resume_v13
				.BringToFront();
			cancel_v13
				.BringToFront();
			progressbar1.BringToFront();
			fs.Enabled = true;
		}

		private void pause2_b_Click(object sender, EventArgs e)
		{
			MP3.PlaybackPause(number);
			pause_state_ = 1;
		}

		private void resume2_Click(object sender, EventArgs e)
		{
			MP3.PlaybackResume(number);
			pause_state_ = 0;
		}

		private void cancel2_Click(object sender, EventArgs e)
		{
			button8_Click(null, null);
		}

		private void esconde_t_Tick(object sender, EventArgs e)
		{
			if (play_v13.Top < 5000)
			{
				esconde_t.Interval = 50;
				play_v13
					.Top = play_v13.Top + 1;
				pause_v13
					.Top = pause_v13.Top + 1;
				resume_v13
					.Top = resume_v13.Top + 1;
				cancel_v13
					.Top = cancel_v13.Top + 1;
				progressbar1.Top = progressbar1.Top + 1;
			}
			else
			{
				esconde_t.Enabled = false;
				esconde_t.Interval = 3000;
			}
		}

		private void disable_video_MouseUp(object sender, MouseEventArgs e)
		{
			MP3.DisableVideo(number, 0);
			if (CheckState.Checked == disable_video.CheckState)
			{
				MP3.DisableVideo(number, 1);
			}
		}

		private void no_draw_MouseUp(object sender, MouseEventArgs e)
		{
			MP3.Don_t_Draw_Video(number, 0);
			if (CheckState.Checked == no_draw.CheckState)
			{
				MP3.Don_t_Draw_Video(number, 1);
			}
		}

		private void default_w_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			int w;
			int h;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				fullscreen_state_ = 1;
				MP3.is_full_screen = true;

				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;

				fs.Enabled = true;

				MP3.GetWindowSize
					(
						number,
						out w,
						out h
					)
					;

				if (0 != w && 0 != h)
				{

					if (1 == w % 2)
					{
						w--;
					}
					if (1 == h % 2)
					{
						h--;
					}
					video_p.Width = w;
					video_p.Height = h;

					int p;

					p = (this.Width - w) / 2;

					video_p.Left = p;

					p = ((((Screen.PrimaryScreen.Bounds.Height) - h))) / 2;

					video_p.Top = p;

					background_p.Visible = true;
					background_p.Width = this.Width;
					background_p.Height = this.Height;
					background_p.Top = 0;
					background_p.Left = 0;
					background_p.BringToFront();

				}
				else
				{
					video_p.Width = this.Width;
					video_p.Height = this.Height;

					video_p.Top = 0;
					video_p.Left = 0;

				}
				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.BringToFront();
				weird_timer.Enabled = true;
				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;
			}
		}

		private void background_p_MouseMove(object sender, MouseEventArgs e)
		{
			show_constrols(e);
		}

		private void background_p_MouseClick(object sender, MouseEventArgs e)
		{
			video_p_MouseClick(null, e);
		}

		private void cancel_imer_Tick(object sender, EventArgs e)
		{
			button8_Click(null, null);
			cancel_imer.Enabled = false;
		}

		private void progressbar1_MouseEnter(object sender, EventArgs e)
		{

		}

		private void progressbar1_MouseLeave(object sender, EventArgs e)
		{

		}

		private void width_plu_plus_Click(object sender, EventArgs e)
		{

			MP3.adjusted_ratio += 0.1;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;

		}

		private void width_minus_minus_Click(object sender, EventArgs e)
		{

			MP3.adjusted_ratio -= 0.1;
			MP3.AdjustRatio(number, MP3.adjusted_ratio);

			MP3.PassWindowInformation
				(
					number,
					video_p.Handle.ToInt64(),
					video_f_p.Handle.ToInt64(),
					video_p.Width,
					video_p.Height,
					the_ratio,
					video_p.Left,
					video_p.Top
				)
				;

		}

		private void weird_timer_Tick(object sender, EventArgs e)
		{
			play_v13
				.Visible = true;
			pause_v13
				.Visible = true;
			resume_v13
				.Visible = true;
			cancel_v13
				.Visible = true;

			play_v13
				.BringToFront();
			pause_v13
				.BringToFront();
			resume_v13
				.BringToFront();
			cancel_v13
				.BringToFront();
			progressbar1.BringToFront();
		}

		private void fs_50_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			int w;
			int h;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				fullscreen_state_ = 1;
				MP3.is_full_screen = true;

				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;

				fs.Enabled = true;

				MP3.GetWindowSize
					(
						number,
						out w,
						out h
					)
					;

				if (0 != w && 0 != h)
				{

					if (1 == w % 2)
					{
						w--;
					}
					if (1 == h % 2)
					{
						h--;
					}
					video_p.Width = w / 2;
					video_p.Height = h / 2;

					int p;

					p = (this.Width - (w / 2)) / 2;

					video_p.Left = p;

					p = ((((Screen.PrimaryScreen.Bounds.Height) - (h / 2)))) / 2;

					video_p.Top = p;

					background_p.Visible = true;
					background_p.Width = this.Width;
					background_p.Height = this.Height;
					background_p.Top = 0;
					background_p.Left = 0;
					background_p.BringToFront();

				}
				else
				{
					video_p.Width = this.Width;
					video_p.Height = this.Height;

					video_p.Top = 0;
					video_p.Left = 0;

				}
				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.BringToFront();
				weird_timer.Enabled = true;
				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;
			}

		}

		private void fs_200_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			int w;
			int h;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				fullscreen_state_ = 1;
				MP3.is_full_screen = true;

				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;

				fs.Enabled = true;

				MP3.GetWindowSize
					(
						number,
						out w,
						out h
					)
					;

				if (0 != w && 0 != h)
				{

					if (1 == w % 2)
					{
						w--;
					}
					if (1 == h % 2)
					{
						h--;
					}
					video_p.Width = w * 2;
					video_p.Height = h * 2;

					int p;

					p = (this.Width - (w * 2)) / 2;

					video_p.Left = p;

					p = ((((Screen.PrimaryScreen.Bounds.Height) - h * 2))) / 2;

					video_p.Top = p;

					background_p.Visible = true;
					background_p.Width = this.Width;
					background_p.Height = this.Height;
					background_p.Top = 0;
					background_p.Left = 0;
					background_p.BringToFront();

				}
				else
				{
					video_p.Width = this.Width;
					video_p.Height = this.Height;

					video_p.Top = 0;
					video_p.Left = 0;

				}
				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.BringToFront();
				weird_timer.Enabled = true;
				MP3.DisableWidthLimit(number);
				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;
			}

		}

		private void fs_by_heigth_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			int w;
			int h;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				fullscreen_state_ = 1;
				MP3.is_full_screen = true;

				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;

				fs.Enabled = true;

				MP3.GetWindowSize
					(
						number,
						out w,
						out h
					)
					;

				if (0 != w && 0 != h)
				{

					double ratio = (double)w / (double)h;//2


				again:
					;

					while (h < this.Height)
					{
						w++;
						double hh;
						double ww = w;
						hh = ww / ratio;
						h = (int)hh;
						goto again;
					}

					if (1 == w % 2)
					{
						w--;
					}
					if (1 == h % 2)
					{
						h--;
					}
					video_p.Width = w;
					video_p.Height = h;

					int p;

					p = (this.Width - w) / 2;

					video_p.Left = p;

					p = ((((Screen.PrimaryScreen.Bounds.Height) - h))) / 2;

					video_p.Top = p;

					background_p.Visible = true;
					background_p.Width = this.Width;
					background_p.Height = this.Height;
					background_p.Top = 0;
					background_p.Left = 0;
					background_p.BringToFront();

				}
				else
				{
					video_p.Width = this.Width;
					video_p.Height = this.Height;

					video_p.Top = 0;
					video_p.Left = 0;

				}
				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.BringToFront();
				weird_timer.Enabled = true;

				MP3.DisableWidthLimit(number);

				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;
			}
		}

		private void fs_300_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			int w;
			int h;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				fullscreen_state_ = 1;
				MP3.is_full_screen = true;

				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;

				fs.Enabled = true;

				MP3.GetWindowSize
					(
						number,
						out w,
						out h
					)
					;

				if (0 != w && 0 != h)
				{

					if (1 == w % 2)
					{
						w--;
					}
					if (1 == h % 2)
					{
						h--;
					}
					video_p.Width = w * 3;
					video_p.Height = h * 3;

					int p;

					p = (this.Width - (w * 3)) / 2;

					video_p.Left = p;

					p = ((((Screen.PrimaryScreen.Bounds.Height) - h * 3))) / 2;

					video_p.Top = p;

					background_p.Visible = true;
					background_p.Width = this.Width;
					background_p.Height = this.Height;
					background_p.Top = 0;
					background_p.Left = 0;
					background_p.BringToFront();

				}
				else
				{
					video_p.Width = this.Width;
					video_p.Height = this.Height;

					video_p.Top = 0;
					video_p.Left = 0;

				}
				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.BringToFront();
				weird_timer.Enabled = true;
				MP3.DisableWidthLimit(number);
				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;
			}

		}

		private void fs_400_Click(object sender, EventArgs e)
		{

			pause_state_ = 0;

			int w;
			int h;
			double position = MP3.PlayBackPosition_AV_TIME_BASE(number);

			if (true)
			{
				fullscreen_state_ = 1;
				MP3.is_full_screen = true;

				this.FormBorderStyle = FormBorderStyle.None;
				this.WindowState = FormWindowState.Maximized;

				fs.Enabled = true;

				MP3.GetWindowSize
					(
						number,
						out w,
						out h
					)
					;

				if (0 != w && 0 != h)
				{

					if (1 == w % 2)
					{
						w--;
					}
					if (1 == h % 2)
					{
						h--;
					}
					video_p.Width = w * 4;
					video_p.Height = h * 4;

					int p;

					p = (this.Width - (w * 4)) / 2;

					video_p.Left = p;

					p = ((((Screen.PrimaryScreen.Bounds.Height) - h * 4))) / 2;

					video_p.Top = p;

					background_p.Visible = true;
					background_p.Width = this.Width;
					background_p.Height = this.Height;
					background_p.Top = 0;
					background_p.Left = 0;
					background_p.BringToFront();

				}
				else
				{
					video_p.Width = this.Width;
					video_p.Height = this.Height;

					video_p.Top = 0;
					video_p.Left = 0;

				}
				progressbar1.Width = this.Width - 56;

				int val = (this.Width - progressbar1.Width) / 2;

				progressbar1.Left = val - 5;

				if (1 == video_p.Height % 2)//these values always need to be a a multiple of 2
				{
					video_p.Height--;
				}
				if (1 == video_p.Width % 2)
				{
					video_p.Width--;
				}

				video_p.BringToFront();
				weird_timer.Enabled = true;
				MP3.DisableWidthLimit(number);
				MP3.PassWindowInformation
					(
						number,
						video_p.Handle.ToInt64(),
						video_f_p.Handle.ToInt64(),
						video_p.Width,
						video_p.Height,
						the_ratio,
						video_p.Left,
						video_p.Top
					)
					;

				fs.Enabled = true;
			}

		}

		private void button4_Click_1(object sender, EventArgs e)
		{
			if (false == playlist.Visible)
			{
				playlist.Visible = true;
				playlist.BringToFront();
				playlist.Focus();
				playlist.Activation = ItemActivation.Standard;
			}
			else
			{
				playlist.Visible = false;
			}
		}

		private void randon_MouseUp(object sender, MouseEventArgs e)
		{
			MP3.SaveSettings("randon", "0");
			MP3.is_shuffle = false;
			if (CheckState.Checked == randon.CheckState)
			{
				MP3.SaveSettings("randon", "1");
				MP3.is_shuffle = true;
			}
		}

		private void playlist_DoubleClick(object sender, EventArgs e)
		{
			ListViewItem coisa = playlist.SelectedItems[0];
			MP3.playlist_index = playlist.SelectedItems[0].Index;
			int loop_ = 0;
			if (CheckState.Checked == loop.CheckState)
			{
				loop_ = 1;
			}
			file_l.Text = coisa.SubItems[0].Text;
			MP3.Play(number, MP3.wide2utf8(coisa.SubItems[1].Text), loop_, int.Parse(track.Text),
			         video_p.Handle.ToInt64(),
			         video_f_p.Handle.ToInt64(),
			         video_p.Width,
			         video_p.Height,
			         the_ratio,
			         video_p.Left,
			         video_p.Top);
			playlist.Visible = false;
		}

		private void playlist_MouseUp(object sender, MouseEventArgs e)
		{

		}

		private void playlist_KeyUp(object sender, KeyEventArgs e)
		{


			ListViewItem coisa = playlist.SelectedItems[0];
			MP3.playlist_index = playlist.SelectedItems[0].Index;
			MP3.the_filename = coisa.SubItems[1].Text;
			

		}

		private void playlist_KeyDown(object sender, KeyEventArgs e)
		{
			

		}

		private void playlist_Click(object sender, EventArgs e)
		{

			ListViewItem coisa = playlist.SelectedItems[0];
			MP3.playlist_index = playlist.SelectedItems[0].Index;
			MP3.the_filename = coisa.SubItems[1].Text;

		}

		private void button27_Click(object sender, EventArgs e)
		{
			double p

				;

			try
			{
				p = double.Parse(sync_t.Text);
				MP3.AdjustSync(number, p);
			}
			catch
			{
				sync_t.Text = "0";
			}
		}

		private void open_v12_Click(object sender, EventArgs e)
		{
			button6_Click(null, null);
		}

		private void play_v12_Click(object sender, EventArgs e)
		{
			button4_Click(null, null);
		}

		private void pause_v12_Click(object sender, EventArgs e)
		{
			button7_Click(null, null);
		}

		private void resume_v12_Click(object sender, EventArgs e)
		{
			button5_Click(null, null);
		}

		private void cancel_v12_Click(object sender, EventArgs e)
		{
			button8_Click(null, null);
		}

		private void select_v12_Click(object sender, EventArgs e)
		{
			button2_Click(null, null);
		}

		private void play_v13_Click(object sender, EventArgs e)
		{
			play2_b_Click(null, null);
		}

		private void pause_v13_Click(object sender, EventArgs e)
		{
			pause2_b_Click(null, null);
		}

		private void resume_v13_Click(object sender, EventArgs e)
		{
			resume2_Click(null, null);
		}

		private void cancel_v13_Click(object sender, EventArgs e)
		{
			cancel2_Click(null, null);
		}

		private void by_RSP_Software_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start("http://nomade.sourceforge.net/");
		}
		void PlaylistColumnClick(object sender, ColumnClickEventArgs e)
		{
			
			// Determine if clicked column is already the column that is being sorted.
			if (e.Column == lvwColumnSorter.SortColumn) {
				// Reverse the current sort direction for this column.
				if (lvwColumnSorter.Order == SortOrder.Ascending) {
					lvwColumnSorter.Order = SortOrder.Descending;
				} else {
					lvwColumnSorter.Order = SortOrder.Ascending;
				}
			} else {
				// Set the column number that is to be sorted; default to ascending.
				lvwColumnSorter.SortColumn = e.Column;
				lvwColumnSorter.Order = SortOrder.Ascending;
			}

			// Perform the sort with these new sort options.
			this.playlist.Sort();
		}		
	}
}
